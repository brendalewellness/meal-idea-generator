/* ============================================================================
   MEAL LIBRARY  --  Recipe library (editable at runtime via the UI)
   ----------------------------------------------------------------------------
   Field reference:
     id        unique id
     type      breakfast | lunch | dinner | snack
     carb      low | moderate
     tags      filter tags (multi-select):
               gut-healing . asian . quick-easy . no-cook . batch-cook
               high-protein . vegetarian . vegan . gluten-free
     contains  allergens present (for "avoid" filter):
               dairy . gluten . nuts . egg . soy . fish . shellfish . sesame
     focus     EDITABLE display labels shown on the card / handout
               (defaults below mirror the tag-derived labels; the user can
                override these via the Recipe Library editor without
                touching the filter tags)
     img       image filename in /images, OR a data: URI (uploaded via UI),
               OR null to use the emoji placeholder
     emoji     placeholder icon (used when img is null)
     macros    per-serving nutrition: { protein, fat, netCarbs }
               each with { g, pct }  (grams + % of calories from that macro)
     en / zh   bilingual copy, each with:
               name . time . servings . why . ingredients[] . steps[] . notes
   ========================================================================== */

const MEALS = [
    {
      id: 'b1',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'quick-easy',
        'gut-healing',
        'high-protein',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'dairy'
      ],
      focus: [
        'Gut-healing',
        'High protein'
      ],
      img: 'greek-yogurt-berry-bowl.jpg',
      emoji: '🥣',
      en: {
        name: 'Greek Yogurt Berry Bowl',
        time: '5 min',
        servings: '1',
        why: 'A probiotic, protein-rich start that keeps blood sugar steady.',
        ingredients: [
          'Greek yogurt 200g (unsweetened)',
          'Mixed berries, 1 small bowl (fresh or frozen)',
          'Ground flaxseed 1 tbsp',
          'Cinnamon, a pinch',
          '(Optional) a little raw honey'
        ],
        steps: [
          'Spoon the yogurt into a bowl and smooth the top.',
          'Pile the berries on top; sprinkle with flaxseed and cinnamon.',
          'Add a drizzle of honey only if a little sweetness is needed.'
        ],
        notes: 'Lactose-sensitive? Use coconut yogurt. For a lighter version, use 0% Greek yogurt.'
      },
      zh: {
        name: '希腊酸奶莓果碗',
        time: '5 分钟',
        servings: '1 份',
        why: '益生菌 + 优质蛋白的开场，升糖平稳，适合作为一天的稳定起点。',
        ingredients: [
          '希腊酸奶 200g（无糖）',
          '混合莓果 1 小碗（新鲜或冷冻）',
          '亚麻籽 1 汤匙',
          '肉桂粉 少许',
          '（可选）少量生蜂蜜'
        ],
        steps: [
          '酸奶盛入碗中，用勺背抹平。',
          '莓果铺在酸奶上，撒亚麻籽与肉桂粉。',
          '如需甜味，淋极少量生蜂蜜即可。'
        ],
        notes: '乳糖敏感者可换成椰子酸奶；想更低脂用 0% 希腊酸奶。'
      },
      macros: {
        protein: {
          g: 22,
          pct: 35
        },
        fat: {
          g: 5,
          pct: 18
        },
        netCarbs: {
          g: 20,
          pct: 47
        }
      }
    },
    {
      id: 'b2',
      type: 'breakfast',
      carb: 'low',
      tags: [
        'quick-easy',
        'gut-healing',
        'high-protein',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'egg',
        'dairy'
      ],
      focus: [
        'Gut-healing',
        'High protein'
      ],
      img: 'spinach-mushroom-omelette.jpg',
      emoji: '🍳',
      en: {
        name: 'Spinach & Mushroom Omelette',
        time: '10 min',
        servings: '1',
        why: 'Low-carb and high-protein, with soluble fibre and minerals from spinach and mushrooms.',
        ingredients: [
          'Eggs 3',
          'Baby spinach, 1 handful',
          'White mushrooms 4–5 (sliced)',
          'Olive oil 1 tsp',
          'Sea salt, black pepper to taste',
          '(Optional) a little feta'
        ],
        steps: [
          'Beat and season the eggs. Heat the oil and sauté the mushrooms until golden.',
          'Add spinach and cook until just wilted; pour in the eggs and spread evenly.',
          'Cook on low until set, then fold and serve.'
        ],
        notes: 'Egg-sensitive? Swap for a firm tofu scramble.'
      },
      zh: {
        name: '菠菜蘑菇欧姆蛋',
        time: '10 分钟',
        servings: '1 份',
        why: '低碳高蛋白，菠菜与蘑菇提供可溶性纤维与矿物质，血糖友好。',
        ingredients: [
          '鸡蛋 3 个',
          '嫩菠菜 1 把',
          '白蘑菇 4–5 朵（切片）',
          '橄榄油 1 茶匙',
          '海盐、黑胡椒 适量',
          '（可选）羊奶酪 少许'
        ],
        steps: [
          '鸡蛋打散调味；热锅下橄榄油，炒香蘑菇至微黄。',
          '加菠菜炒至刚软，倒入蛋液铺平。',
          '小火煎至凝固，对折出锅。'
        ],
        notes: '对蛋敏感者换豆腐炒（firm tofu scramble）。'
      },
      macros: {
        protein: {
          g: 25,
          pct: 50
        },
        fat: {
          g: 18,
          pct: 40
        },
        netCarbs: {
          g: 4,
          pct: 10
        }
      }
    },
    {
      id: 'b3',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'no-cook',
        'batch-cook',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Gut-healing',
        'Batch-cook'
      ],
      img: 'overnight-chia-pudding.jpg',
      emoji: '🥥',
      en: {
        name: 'Overnight Chia Pudding',
        time: '5 min + overnight',
        servings: '2',
        why: 'No-cook and make-ahead; rich in soluble fibre for a zero-effort breakfast.',
        ingredients: [
          'Chia seeds 4 tbsp',
          'Unsweetened coconut or almond milk 250ml',
          'Vanilla extract, a few drops',
          '(Optional) maple syrup 1 tsp',
          'Fresh berries / coconut flakes to top'
        ],
        steps: [
          'Stir the chia into the milk; after 10 minutes stir again to break up clumps.',
          'Cover and chill at least 4 hours, or overnight.',
          'Top with berries and coconut flakes before serving.'
        ],
        notes: 'Make 3–4 jars at once — keeps 4 days in the fridge. A classic batch-cook item.'
      },
      zh: {
        name: '隔夜奇亚籽布丁',
        time: '5 分钟 + 过夜',
        servings: '2 份',
        why: '免烹、可一次做几份冷藏，可溶性纤维丰富，早餐零负担。',
        ingredients: [
          '奇亚籽 4 汤匙',
          '无糖椰奶或杏仁奶 250ml',
          '香草精 数滴',
          '（可选）枫糖 1 茶匙',
          '新鲜莓果 / 椰蓉 点缀'
        ],
        steps: [
          '奇亚籽与奶液搅匀，静置 10 分钟后再搅一次防止结块。',
          '盖好冷藏至少 4 小时或过夜。',
          '食用前加莓果与椰蓉。'
        ],
        notes: '一次做 3–4 罐，冷藏可存 4 天，是 batch-cook 的典型。'
      },
      macros: {
        protein: {
          g: 6,
          pct: 12
        },
        fat: {
          g: 10,
          pct: 45
        },
        netCarbs: {
          g: 12,
          pct: 43
        }
      }
    },
    {
      id: 'b4',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'asian',
        'gut-healing',
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Gut-healing',
        'Asian'
      ],
      img: 'ginger-scallion-congee.jpg',
      emoji: '🍚',
      en: {
        name: 'Ginger Scallion Congee',
        time: '40 min',
        servings: '4',
        why: 'Gentle and easy to digest — ideal during a sensitive gut phase. Makes two days of breakfast.',
        ingredients: [
          'White rice 1 cup',
          'Chicken stock or water 8 cups',
          'Shredded chicken breast 150g',
          'Ginger, julienned 1 tbsp',
          'Scallions to taste',
          'Sea salt, white pepper to taste'
        ],
        steps: [
          'Rinse the rice, add the stock and bring to a boil; simmer 30 minutes until broken down.',
          'Add the chicken and ginger; cook 5 more minutes.',
          'Season and finish with scallions.'
        ],
        notes: 'For a gut-healing phase, use skinless chicken and a clear broth.'
      },
      zh: {
        name: '姜葱鸡肉粥',
        time: '40 分钟',
        servings: '4 份',
        why: '温和易消化，适合肠胃敏感期；一次煮一锅可吃两天。',
        ingredients: [
          '大米 1 杯',
          '鸡汤或清水 8 杯',
          '鸡胸肉丝 150g',
          '姜丝 1 汤匙',
          '葱花 适量',
          '海盐、白胡椒 适量'
        ],
        steps: [
          '米洗净加汤煮开，转小火慢熬 30 分钟至米开花。',
          '加入鸡丝与姜丝再煮 5 分钟。',
          '调味，撒葱花出锅。'
        ],
        notes: '肠道修复期可去掉鸡皮、只用清汤，更清爽。'
      },
      macros: {
        protein: {
          g: 20,
          pct: 30
        },
        fat: {
          g: 3,
          pct: 10
        },
        netCarbs: {
          g: 35,
          pct: 60
        }
      }
    },
    {
      id: 'b5',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'quick-easy',
        'high-protein'
      ],
      contains: [
        'fish',
        'gluten'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: 'smoked-salmon-avocado-toast.jpg',
      emoji: '🥑',
      en: {
        name: 'Smoked Salmon Avocado Toast',
        time: '7 min',
        servings: '1',
        why: 'Omega-3s, healthy fats and protein — satisfying for a busy morning.',
        ingredients: [
          'Wholegrain or sourdough bread 1 slice',
          'Avocado 1/2',
          'Smoked salmon 60g',
          'Lemon juice, sea salt, black pepper',
          '(Optional) capers, dill'
        ],
        steps: [
          'Toast the bread until crisp; mash the avocado on top.',
          'Layer on the salmon, squeeze over lemon, season with salt and pepper.'
        ],
        notes: 'Gluten-free? Use gluten-free bread. Vegetarian? Try smoked tofu instead.'
      },
      zh: {
        name: '烟熏三文鱼牛油果吐司',
        time: '7 分钟',
        servings: '1 份',
        why: 'Omega-3 + 好脂肪 + 蛋白，饱腹感强，适合忙碌早晨。',
        ingredients: [
          '全麦或酸面包 1 片',
          '牛油果 半个',
          '烟熏三文鱼 60g',
          '柠檬汁、海盐、黑胡椒 适量',
          '（可选）刺山柑、莳萝'
        ],
        steps: [
          '面包烤至微脆，牛油果压成泥抹上。',
          '铺三文鱼，挤柠檬汁，撒盐与黑胡椒。'
        ],
        notes: '需要无麸质者换无麸质面包；素食者可用烟熏豆腐替代。'
      },
      macros: {
        protein: {
          g: 25,
          pct: 35
        },
        fat: {
          g: 18,
          pct: 45
        },
        netCarbs: {
          g: 15,
          pct: 20
        }
      }
    },
    {
      id: 'b6',
      type: 'breakfast',
      carb: 'low',
      tags: [
        'quick-easy',
        'gut-healing',
        'high-protein',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'egg'
      ],
      focus: [
        'Gut-healing',
        'High protein'
      ],
      img: 'turmeric-veggie-scramble.jpg',
      emoji: '🍳',
      en: {
        name: 'Turmeric Veggie Scramble',
        time: '10 min',
        servings: '1',
        why: 'Turmeric is anti-inflammatory; peppers and onions add antioxidants.',
        ingredients: [
          'Eggs 3',
          'Bell pepper and onion, 1/4 each (diced)',
          'Turmeric 1/4 tsp',
          'Olive oil 1 tsp',
          'Sea salt, black pepper to taste'
        ],
        steps: [
          'Heat the oil and soften the onion and pepper.',
          'Stir in the turmeric, then add the eggs and scramble until just set.'
        ],
        notes: 'Pair turmeric with black pepper for better absorption. Egg-sensitive? Use scrambled tofu.'
      },
      zh: {
        name: '姜黄蔬菜炒蛋',
        time: '10 分钟',
        servings: '1 份',
        why: '姜黄有助抗炎，搭配彩椒洋葱补充抗氧化物质。',
        ingredients: [
          '鸡蛋 3 个',
          '彩椒、洋葱 各 1/4 个（切丁）',
          '姜黄粉 1/4 茶匙',
          '橄榄油 1 茶匙',
          '海盐、黑胡椒 适量'
        ],
        steps: [
          '热锅下油，炒软洋葱与彩椒。',
          '加姜黄粉略炒，倒入蛋液翻炒至凝固即可。'
        ],
        notes: '姜黄配黑胡椒吸收更好；对蛋敏感者可换炒豆腐。'
      },
      macros: {
        protein: {
          g: 22,
          pct: 50
        },
        fat: {
          g: 16,
          pct: 40
        },
        netCarbs: {
          g: 4,
          pct: 10
        }
      }
    },
    {
      id: 'b7',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'no-cook',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Gut-healing',
        'No-cook'
      ],
      img: 'coconut-yogurt-chia-parfait.jpg',
      emoji: '🥥',
      en: {
        name: 'Coconut Yogurt Chia Parfait',
        time: '6 min',
        servings: '1',
        why: 'Fully plant-based and no-cook; coconut yogurt suits lactose intolerance.',
        ingredients: [
          'Coconut yogurt 180g',
          'Chia seeds 1 tbsp',
          'Blueberries, 1 small handful',
          'Unsweetened coconut flakes 1 tsp',
          '(Optional) a little maple syrup'
        ],
        steps: [
          'Layer coconut yogurt in a glass and scatter over the chia.',
          'Add another layer of yogurt and the blueberries; finish with coconut flakes.'
        ],
        notes: 'Stir the chia in 10 minutes ahead for a thicker texture.'
      },
      zh: {
        name: '椰奶奇亚帕妃杯',
        time: '6 分钟',
        servings: '1 份',
        why: '全植物、免烹，椰奶发酵制品对乳糖不耐者友好。',
        ingredients: [
          '椰子酸奶 180g',
          '奇亚籽 1 汤匙',
          '蓝莓 1 小把',
          '无糖椰蓉 1 茶匙',
          '（可选）少量枫糖'
        ],
        steps: [
          '杯底铺一层椰子酸奶，撒奇亚籽。',
          '再叠酸奶与蓝莓，顶层撒椰蓉。'
        ],
        notes: '提前 10 分钟拌入奇亚籽口感更稠。'
      },
      macros: {
        protein: {
          g: 5,
          pct: 12
        },
        fat: {
          g: 12,
          pct: 50
        },
        netCarbs: {
          g: 12,
          pct: 38
        }
      }
    },
    {
      id: 'b8',
      type: 'breakfast',
      carb: 'low',
      tags: [
        'asian',
        'quick-easy',
        'gut-healing',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'egg',
        'soy',
        'sesame'
      ],
      focus: [
        'Gut-healing',
        'Asian'
      ],
      img: 'steamed-egg-custard.jpg',
      emoji: '🥚',
      en: {
        name: 'Steamed Egg Custard',
        time: '15 min',
        servings: '2',
        why: 'Silky and very easy to digest — high protein, low carb. Good for a weak appetite or recovery.',
        ingredients: [
          'Eggs 2',
          'Warm water 180ml (about 1.5× the egg)',
          'Gluten-free soy sauce (tamari) 1 tsp',
          'Sesame oil, a few drops',
          'Scallions, chopped'
        ],
        steps: [
          'Whisk the eggs with the warm water and strain to remove foam.',
          'Cover with cling film, prick a hole, and steam over medium heat for 10 minutes.',
          'Drizzle with tamari and sesame oil; scatter over scallions.'
        ],
        notes: 'Keep the heat moderate or the custard will become honeycombed.'
      },
      zh: {
        name: '中式蒸水蛋',
        time: '15 分钟',
        servings: '2 份',
        why: '极嫩易消化，高蛋白低碳，适合胃口弱或术后恢复期。',
        ingredients: [
          '鸡蛋 2 个',
          '温水 180ml（约蛋液 1.5 倍）',
          '无麸质生抽 (tamari) 1 茶匙',
          '香油 数滴',
          '葱花 少许'
        ],
        steps: [
          '蛋液加温水搅匀，过筛去泡。',
          '盖保鲜膜戳孔，水开后中火蒸 10 分钟。',
          '淋生抽与香油，撒葱花。'
        ],
        notes: '蒸时火力别太大，否则会起蜂窝。'
      },
      macros: {
        protein: {
          g: 12,
          pct: 45
        },
        fat: {
          g: 8,
          pct: 35
        },
        netCarbs: {
          g: 4,
          pct: 20
        }
      }
    },
    {
      id: 'b9',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'quick-easy',
        'batch-cook',
        'vegetarian'
      ],
      contains: [
        'egg',
        'dairy'
      ],
      focus: [
        'Quick & easy',
        'Batch-cook'
      ],
      img: null,
      emoji: '🥞',
      en: {
        name: 'Banana Oat Pancakes',
        time: '15 min',
        servings: '2',
        why: 'Naturally sweetened with banana — a family-friendly batch-cook breakfast.',
        ingredients: [
          'Rolled oats 1 cup',
          'Bananas 2 (ripe)',
          'Eggs 2',
          'Cinnamon 1/2 tsp',
          'Baking powder 1 tsp',
          'Coconut oil for cooking'
        ],
        steps: [
          'Blend oats, banana, eggs, cinnamon and baking powder to a batter.',
          'Cook spoonfuls in a hot pan with coconut oil until golden on both sides.',
          'Keep warm in the oven; extras freeze well.'
        ],
        notes: 'Top with nut butter and berries instead of syrup.'
      },
      zh: {
        name: '香蕉燕麦松饼',
        time: '15 分钟',
        servings: '2 份',
        why: '用香蕉天然甜味，适合全家一起吃的批量早餐。',
        ingredients: [
          '燕麦片 1 杯',
          '熟透香蕉 2 根',
          '鸡蛋 2 个',
          '肉桂粉 1/2 茶匙',
          '泡打粉 1 茶匙',
          '椰子油 适量'
        ],
        steps: [
          '燕麦、香蕉、鸡蛋、肉桂与泡打粉打成糊。',
          '热锅刷椰子油，舀入面糊煎至两面金黄。',
          '多余的可冷冻保存。'
        ],
        notes: '搭配坚果酱和莓果，比枫糖更健康。'
      },
      macros: {
        protein: {
          g: 14,
          pct: 25
        },
        fat: {
          g: 8,
          pct: 32
        },
        netCarbs: {
          g: 26,
          pct: 43
        }
      }
    },
    {
      id: 'b10',
      type: 'breakfast',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'high-protein',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'dairy'
      ],
      focus: [
        'High protein',
        'No-cook'
      ],
      img: null,
      emoji: '🥄',
      en: {
        name: 'Cottage Cheese Berry Bowl',
        time: '3 min',
        servings: '1',
        why: 'Cottage cheese is protein-dense and satisfying — a no-cook 3-minute bowl.',
        ingredients: [
          'Low-fat cottage cheese 200g',
          'Mixed berries 1/2 cup',
          'Chia seeds 1 tsp',
          'Cinnamon, a pinch'
        ],
        steps: [
          'Spoon the cottage cheese into a bowl.',
          'Top with berries, chia and cinnamon.'
        ],
        notes: 'Switch berries for kiwi or melon for variety.'
      },
      zh: {
        name: '茅屋奶酪莓果碗',
        time: '3 分钟',
        servings: '1 份',
        why: '茅屋奶酪高蛋白饱腹，3 分钟免烹早餐。',
        ingredients: [
          '低脂茅屋奶酪 200g',
          '混合莓果 1/2 杯',
          '奇亚籽 1 茶匙',
          '肉桂粉 少许'
        ],
        steps: [
          '茅屋奶酪盛入碗中。',
          '加莓果、奇亚籽与肉桂粉即可。'
        ],
        notes: '莓果可换猕猴桃或蜜瓜。'
      },
      macros: {
        protein: {
          g: 25,
          pct: 50
        },
        fat: {
          g: 4,
          pct: 18
        },
        netCarbs: {
          g: 10,
          pct: 32
        }
      }
    },
    {
      id: 'b11',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'egg'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: null,
      emoji: '🍠',
      en: {
        name: 'Sweet Potato Hash with Eggs',
        time: '20 min',
        servings: '2',
        why: 'A balanced savoury breakfast — complex carbs, fibre and protein in one pan.',
        ingredients: [
          'Sweet potato 1 (diced small)',
          'Onion 1/2, bell pepper 1/2 (diced)',
          'Eggs 4',
          'Olive oil 1 tbsp',
          'Paprika, sea salt, black pepper'
        ],
        steps: [
          'Sauté the sweet potato, onion and pepper in oil until tender (~12 min).',
          'Make 4 wells in the hash and crack an egg into each; cover and cook until set.',
          'Season and serve.'
        ],
        notes: 'Use white potato for higher carb, or cauliflower rice for low carb.'
      },
      zh: {
        name: '红薯鸡蛋锅',
        time: '20 分钟',
        servings: '2 份',
        why: '咸香早餐一锅出，复合碳水、纤维与蛋白都齐了。',
        ingredients: [
          '红薯 1 个（切小丁）',
          '洋葱半个、彩椒半个（切丁）',
          '鸡蛋 4 个',
          '橄榄油 1 汤匙',
          '红椒粉、海盐、黑胡椒 适量'
        ],
        steps: [
          '油炒红薯、洋葱、彩椒至软（约 12 分钟）。',
          '挖 4 个坑各打入一个蛋，盖盖焖至凝固。',
          '调味即可。'
        ],
        notes: '想低碳可换花菜米；想高碳可换普通土豆。'
      },
      macros: {
        protein: {
          g: 20,
          pct: 35
        },
        fat: {
          g: 12,
          pct: 38
        },
        netCarbs: {
          g: 16,
          pct: 27
        }
      }
    },
    {
      id: 'b12',
      type: 'breakfast',
      carb: 'low',
      tags: [
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'egg'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: null,
      emoji: '🥑',
      en: {
        name: 'Avocado Egg Boat',
        time: '15 min',
        servings: '1',
        why: 'Baked egg in an avocado — healthy fats and protein, almost no carbs.',
        ingredients: [
          'Avocado 1',
          'Eggs 2',
          'Cherry tomatoes 4 (diced)',
          'Sea salt, black pepper, chives'
        ],
        steps: [
          'Halve the avocado and remove the pit; scoop a little flesh to make room.',
          'Crack an egg into each half; bake at 200°C for 12–15 minutes.',
          'Top with tomatoes, chives and seasoning.'
        ],
        notes: 'Use a small egg or it will overflow — scoop a bigger well.'
      },
      zh: {
        name: '牛油果鸡蛋船',
        time: '15 分钟',
        servings: '1 份',
        why: '牛油果焗蛋，好脂肪 + 蛋白，几乎没有碳水。',
        ingredients: [
          '牛油果 1 个',
          '鸡蛋 2 个',
          '小番茄 4 颗（切丁）',
          '海盐、黑胡椒、细香葱 适量'
        ],
        steps: [
          '牛油果对半切开去核，稍挖空一些。',
          '每半打入一个蛋，200°C 烤 12–15 分钟。',
          '撒小番茄丁、细香葱与调味。'
        ],
        notes: '鸡蛋选小号，否则会溢出——核洞挖大一点。'
      },
      macros: {
        protein: {
          g: 18,
          pct: 38
        },
        fat: {
          g: 16,
          pct: 42
        },
        netCarbs: {
          g: 8,
          pct: 20
        }
      }
    },
    {
      id: 'b13',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'no-cook',
        'quick-easy',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Gut-healing',
        'No-cook'
      ],
      img: null,
      emoji: '🥬',
      en: {
        name: 'Green Smoothie Bowl',
        time: '5 min',
        servings: '1',
        why: 'A fibre-rich, no-cook plant breakfast — gentle on the gut and easy to sip on the go.',
        ingredients: [
          'Spinach 1 handful',
          'Frozen banana 1',
          'Unsweetened almond milk 200ml',
          'Avocado 1/4',
          'Hemp seeds 1 tbsp',
          'Toppings: berries, coconut flakes'
        ],
        steps: [
          'Blend spinach, banana, milk, avocado and hemp seeds until smooth.',
          'Pour into a bowl and add toppings.'
        ],
        notes: 'Add a scoop of plant protein powder for more protein.'
      },
      zh: {
        name: '绿色思慕雪碗',
        time: '5 分钟',
        servings: '1 份',
        why: '高纤维、免烹的植物早餐，肠道温和，出门也能喝。',
        ingredients: [
          '菠菜 1 把',
          '冷冻香蕉 1 根',
          '无糖杏仁奶 200ml',
          '牛油果 1/4 个',
          '火麻籽 1 汤匙',
          '点缀：莓果、椰蓉'
        ],
        steps: [
          '菠菜、香蕉、奶、牛油果与火麻籽打匀。',
          '倒入碗中，加点缀即可。'
        ],
        notes: '想更高蛋白可加一勺植物蛋白粉。'
      },
      macros: {
        protein: {
          g: 6,
          pct: 18
        },
        fat: {
          g: 8,
          pct: 45
        },
        netCarbs: {
          g: 14,
          pct: 37
        }
      }
    },
    {
      id: 'b14',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'quick-easy',
        'gut-healing',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'dairy'
      ],
      focus: [
        'Gut-healing',
        'Quick & easy'
      ],
      img: null,
      emoji: '🫐',
      en: {
        name: 'Blueberry Oatmeal',
        time: '8 min',
        servings: '1',
        why: 'Soluble fibre from oats supports gut health; berries add antioxidants.',
        ingredients: [
          'Rolled oats 1/2 cup',
          'Water or milk 1 cup',
          'Blueberries 1/3 cup',
          'Ground flaxseed 1 tsp',
          'Cinnamon, a pinch',
          '(Optional) maple syrup 1 tsp'
        ],
        steps: [
          'Cook the oats in water or milk according to the package.',
          'Stir in flax and cinnamon; top with blueberries and a touch of maple.'
        ],
        notes: 'Use steel-cut oats for even more fibre (just allow 20 min).'
      },
      zh: {
        name: '蓝莓燕麦粥',
        time: '8 分钟',
        servings: '1 份',
        why: '燕麦的可溶性纤维助肠道，蓝莓补抗氧化物。',
        ingredients: [
          '燕麦片 1/2 杯',
          '水或奶 1 杯',
          '蓝莓 1/3 杯',
          '亚麻籽粉 1 茶匙',
          '肉桂粉 少许',
          '（可选）枫糖 1 茶匙'
        ],
        steps: [
          '燕麦加水或奶按包装说明煮熟。',
          '拌入亚麻籽与肉桂，铺蓝莓，淋少量枫糖。'
        ],
        notes: '用钢切燕麦纤维更高（需 20 分钟）。'
      },
      macros: {
        protein: {
          g: 8,
          pct: 20
        },
        fat: {
          g: 6,
          pct: 30
        },
        netCarbs: {
          g: 20,
          pct: 50
        }
      }
    },
    {
      id: 'b15',
      type: 'breakfast',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'high-protein'
      ],
      contains: [
        'egg',
        'gluten',
        'dairy'
      ],
      focus: [
        'Batch-cook',
        'High protein'
      ],
      img: null,
      emoji: '🌯',
      en: {
        name: 'Freezer Breakfast Burrito',
        time: '30 min + freeze',
        servings: '6',
        why: 'Make a batch on Sunday; grab one on a busy weekday for a protein-rich breakfast.',
        ingredients: [
          'Wholewheat tortillas 6',
          'Eggs 8',
          'Black beans 1 tin',
          'Bell pepper 1 (diced)',
          'Shredded cheese 1/2 cup',
          'Cumin, paprika, sea salt'
        ],
        steps: [
          'Scramble the eggs with the beans, pepper, spices and cheese.',
          'Spoon onto tortillas and roll up tightly.',
          'Wrap each in foil and freeze; reheat from frozen in a pan or microwave.'
        ],
        notes: 'Use gluten-free tortillas if needed. ~3 minutes to reheat.'
      },
      zh: {
        name: '冷冻早餐卷饼',
        time: '30 分钟 + 冷冻',
        servings: '6 份',
        why: '周日做一批冷冻，工作日早上直接热一个，蛋白够。',
        ingredients: [
          '全麦卷饼 6 张',
          '鸡蛋 8 个',
          '黑豆罐头 1 罐',
          '彩椒 1 个（切丁）',
          '奶酪丝 1/2 杯',
          '孜然、红椒粉、海盐 适量'
        ],
        steps: [
          '鸡蛋与黑豆、彩椒、香料、奶酪一起炒散。',
          '舀到饼上卷紧。',
          '每条用锡纸包好冷冻，吃时锅里或微波炉加热。'
        ],
        notes: '无麸质者用无麸质卷饼；加热约 3 分钟。'
      },
      macros: {
        protein: {
          g: 22,
          pct: 35
        },
        fat: {
          g: 14,
          pct: 30
        },
        netCarbs: {
          g: 22,
          pct: 35
        }
      }
    },
    {
      id: 'l1',
      type: 'lunch',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Batch-cook',
        'High protein'
      ],
      img: 'grilled-chicken-quinoa-bowl.jpg',
      emoji: '🍗',
      en: {
        name: 'Grilled Chicken & Quinoa Bowl',
        time: '25 min',
        servings: '3',
        why: 'The classic meal-prep bowl: protein, complex carbs and vegetables — three portions at once.',
        ingredients: [
          'Chicken breast 3',
          'Quinoa 1 cup (dry)',
          'Broccoli 1 head',
          'Cherry tomatoes, 1 handful',
          'Olive oil, lemon, garlic powder, sea salt'
        ],
        steps: [
          'Cook the quinoa in 1:2 water for 15 minutes.',
          'Season and pan-sear or bake the chicken; rest and slice.',
          'Blanch the broccoli and divide everything into three bowls.'
        ],
        notes: 'Keeps 4 days chilled; dress with lemon and olive oil before eating.'
      },
      zh: {
        name: '烤鸡藜麦碗',
        time: '25 分钟',
        servings: '3 份',
        why: '经典备餐碗，蛋白 + 复合碳水 + 蔬菜，一次做三份。',
        ingredients: [
          '鸡胸 3 块',
          '藜麦 1 杯（生）',
          '西兰花 1 颗',
          '小番茄 1 把',
          '橄榄油、柠檬、蒜粉、海盐 适量'
        ],
        steps: [
          '藜麦按 1:2 水煮 15 分钟。',
          '鸡胸调味后煎/烤至熟，静置切片。',
          '西兰花焯水，与藜麦、鸡胸、小番茄分装成碗。'
        ],
        notes: '冷藏 4 天；吃前淋柠檬橄榄油汁。'
      },
      macros: {
        protein: {
          g: 35,
          pct: 40
        },
        fat: {
          g: 10,
          pct: 22
        },
        netCarbs: {
          g: 28,
          pct: 38
        }
      }
    },
    {
      id: 'l2',
      type: 'lunch',
      carb: 'low',
      tags: [
        'asian',
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'soy',
        'sesame'
      ],
      focus: [
        'Asian',
        'Quick & easy'
      ],
      img: 'asian-chicken-lettuce-wraps.jpg',
      emoji: '🥬',
      en: {
        name: 'Asian Chicken Lettuce Wraps',
        time: '15 min',
        servings: '2',
        why: 'Low-carb and crunchy — lettuce replaces the wrap, so it satisfies without spiking blood sugar.',
        ingredients: [
          'Minced chicken breast 250g',
          'Lettuce leaves 8',
          'Shiitake mushrooms 3 (diced)',
          'Garlic and ginger, 1 tsp each',
          'Gluten-free soy sauce (tamari) 1.5 tbsp',
          'Sesame oil 1 tsp',
          'Scallions'
        ],
        steps: [
          'Heat the sesame oil; sauté the garlic and ginger, then add the chicken and break it up.',
          'Add the mushrooms and tamari; cook until the liquid reduces.',
          'Spoon into the lettuce leaves and top with scallions.'
        ],
        notes: 'Soy-free? Use coconut aminos instead of tamari.'
      },
      zh: {
        name: '亚洲鸡肉生菜包',
        time: '15 分钟',
        servings: '2 份',
        why: '低碳、爽脆，用生菜代替饼皮，饱腹又不升糖。',
        ingredients: [
          '鸡胸肉末 250g',
          '生菜叶 8 片',
          '香菇 3 朵（切丁）',
          '蒜末、姜末 各 1 茶匙',
          '无麸质生抽 (tamari) 1.5 汤匙',
          '芝麻油 1 茶匙',
          '葱花'
        ],
        steps: [
          '热锅下麻油，炒香蒜姜，加鸡肉末炒散。',
          '加香菇丁与生抽炒至收汁。',
          '盛入洗净的生菜叶，撒葱花即可。'
        ],
        notes: '需要无大豆者用椰子氨基（coconut aminos）代替生抽。'
      },
      macros: {
        protein: {
          g: 30,
          pct: 45
        },
        fat: {
          g: 14,
          pct: 35
        },
        netCarbs: {
          g: 8,
          pct: 20
        }
      }
    },
    {
      id: 'l3',
      type: 'lunch',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'gut-healing',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish'
      ],
      focus: [
        'No-cook',
        'High protein'
      ],
      img: 'tuna-avocado-salad.jpg',
      emoji: '🥗',
      en: {
        name: 'Tuna Avocado Salad',
        time: '8 min',
        servings: '1',
        why: 'No-cook and done in five minutes — healthy fats and protein to avoid an afternoon slump.',
        ingredients: [
          'Tuna in water 1 tin',
          'Avocado 1',
          'Celery 1 stalk (diced)',
          'Lemon juice 1 tbsp',
          'Olive oil 1 tsp',
          'Sea salt, black pepper'
        ],
        steps: [
          'Drain the tuna and toss with the avocado and celery.',
          'Dress with lemon and olive oil; season to taste.'
        ],
        notes: 'Serve in lettuce leaves or cucumber cups to keep it lower carb.'
      },
      zh: {
        name: '金枪鱼牛油果沙拉',
        time: '8 分钟',
        servings: '1 份',
        why: '免烹、5 分钟搞定，好脂肪 + 蛋白，下午不犯困。',
        ingredients: [
          '水浸金枪鱼 1 罐',
          '牛油果 1 个',
          '芹菜 1 根（切丁）',
          '柠檬汁 1 汤匙',
          '橄榄油 1 茶匙',
          '海盐、黑胡椒'
        ],
        steps: [
          '金枪鱼沥干，与牛油果块、芹菜拌匀。',
          '淋柠檬汁与橄榄油，调味即可。'
        ],
        notes: '配生菜叶或黄瓜片当"船"吃，更低碳。'
      },
      macros: {
        protein: {
          g: 28,
          pct: 50
        },
        fat: {
          g: 15,
          pct: 38
        },
        netCarbs: {
          g: 4,
          pct: 12
        }
      }
    },
    {
      id: 'l4',
      type: 'lunch',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Gut-healing',
        'Batch-cook'
      ],
      img: 'lentil-roasted-veg-soup.jpg',
      emoji: '🍲',
      en: {
        name: 'Lentil & Roasted Veg Soup',
        time: '40 min',
        servings: '4',
        why: 'Plant protein plus plenty of soluble fibre — a gentle workhorse for a gut-healing phase.',
        ingredients: [
          'Red lentils 1 cup',
          'Carrot, celery, onion, as needed',
          'Tinned tomatoes 1 tin',
          'Vegetable stock 1L',
          'Cumin and turmeric, 1/2 tsp each',
          'Olive oil 1 tbsp'
        ],
        steps: [
          'Sweat the onion, carrot and celery in olive oil.',
          'Add the lentils, tomatoes, stock and spices; simmer 25 minutes.',
          'Mash lightly with a spoon for a thicker texture and season.'
        ],
        notes: 'Keeps 5 days chilled, 3 months frozen — very low effort.'
      },
      zh: {
        name: '扁豆烤蔬菜浓汤',
        time: '40 分钟',
        servings: '4 份',
        why: '植物蛋白 + 大量可溶性纤维，是肠道修复期的温和主力。',
        ingredients: [
          '红扁豆 1 杯',
          '胡萝卜、西芹、洋葱 各适量',
          '番茄罐头 1 罐',
          '蔬菜高汤 1L',
          '孜然、姜黄 各 1/2 茶匙',
          '橄榄油 1 汤匙'
        ],
        steps: [
          '橄榄油炒香洋葱、胡萝卜、西芹。',
          '加扁豆、番茄、高汤与香料，煮开后小火 25 分钟。',
          '用勺背略压出浓稠感，调味即可。'
        ],
        notes: '冷藏 5 天、冷冻 3 个月，非常省事。'
      },
      macros: {
        protein: {
          g: 12,
          pct: 25
        },
        fat: {
          g: 6,
          pct: 25
        },
        netCarbs: {
          g: 22,
          pct: 50
        }
      }
    },
    {
      id: 'l5',
      type: 'lunch',
      carb: 'moderate',
      tags: [
        'asian',
        'gut-healing',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish',
        'soy'
      ],
      focus: [
        'Gut-healing',
        'Asian'
      ],
      img: 'miso-salmon-rice-bowl.jpg',
      emoji: '🍣',
      en: {
        name: 'Miso Salmon Rice Bowl',
        time: '20 min',
        servings: '2',
        why: 'Fermented miso supports the gut and salmon adds omega-3s — a balanced single bowl.',
        ingredients: [
          'Salmon 2 fillets',
          'Miso 1 tbsp (choose gluten-free)',
          'Mirin 1 tbsp',
          'Brown rice 2 bowls',
          'Edamame, 1 small bowl',
          'Cucumber, shredded nori'
        ],
        steps: [
          'Mix the miso and mirin into a glaze; coat the salmon and rest 10 minutes.',
          'Pan-sear or bake the salmon until cooked through.',
          'Bowl up the rice, add the salmon, edamame and cucumber, and finish with nori.'
        ],
        notes: 'Check the miso label — most contain barley, so choose gluten-free if needed.'
      },
      zh: {
        name: '味噌三文鱼饭碗',
        time: '20 分钟',
        servings: '2 份',
        why: '发酵味噌有益肠道，三文鱼补 Omega-3，一碗均衡。',
        ingredients: [
          '三文鱼 2 块',
          '味噌 1 汤匙（选无麸质）',
          '味醂 1 汤匙',
          '糙米饭 2 碗',
          '毛豆 1 小碗',
          '黄瓜片、海苔丝 适量'
        ],
        steps: [
          '味噌与味醂调成酱，抹在三文鱼上腌 10 分钟。',
          '煎或烤三文鱼至熟。',
          '糙米饭打底，摆三文鱼、毛豆、黄瓜，撒海苔丝。'
        ],
        notes: '需要无麸质者选无麸质味噌（多数味噌含大麦）。'
      },
      macros: {
        protein: {
          g: 32,
          pct: 38
        },
        fat: {
          g: 12,
          pct: 28
        },
        netCarbs: {
          g: 22,
          pct: 34
        }
      }
    },
    {
      id: 'l6',
      type: 'lunch',
      carb: 'moderate',
      tags: [
        'quick-easy',
        'high-protein'
      ],
      contains: [
        'gluten',
        'sesame'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: 'turkey-hummus-wrap.jpg',
      emoji: '🌯',
      en: {
        name: 'Turkey & Hummus Wrap',
        time: '7 min',
        servings: '1',
        why: 'A seven-minute meal to go: protein plus fibre, far better than takeaway.',
        ingredients: [
          'Wholewheat wrap 1',
          'Sliced turkey breast 80g',
          'Hummus 2 tbsp',
          'Lettuce, tomato, red onion'
        ],
        steps: [
          'Warm the wrap briefly and spread with hummus.',
          'Layer on the turkey, lettuce, tomato and onion; roll tightly and halve.'
        ],
        notes: 'Gluten-free? Use lettuce cups or a corn tortilla.'
      },
      zh: {
        name: '火鸡鹰嘴豆泥卷',
        time: '7 分钟',
        servings: '1 份',
        why: '7 分钟出门餐，蛋白 + 纤维，比外卖好太多。',
        ingredients: [
          '全麦卷饼 1 张',
          '火鸡胸片 80g',
          '鹰嘴豆泥 2 汤匙',
          '生菜、番茄片、紫洋葱 适量'
        ],
        steps: [
          '卷饼微热，抹鹰嘴豆泥。',
          '铺火鸡、生菜、番茄、洋葱，卷紧对半切。'
        ],
        notes: '无麸质者用生菜或玉米饼代替。'
      },
      macros: {
        protein: {
          g: 25,
          pct: 35
        },
        fat: {
          g: 12,
          pct: 30
        },
        netCarbs: {
          g: 22,
          pct: 35
        }
      }
    },
    {
      id: 'l7',
      type: 'lunch',
      carb: 'low',
      tags: [
        'quick-easy',
        'gut-healing',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'nuts',
        'dairy'
      ],
      focus: [
        'Gut-healing',
        'Quick & easy'
      ],
      img: 'zucchini-noodle-pesto-bowl.jpg',
      emoji: '🥒',
      en: {
        name: 'Zucchini Noodle Pesto Bowl',
        time: '12 min',
        servings: '1',
        why: 'Zucchini replaces pasta, cutting carbs sharply; pesto brings healthy fats.',
        ingredients: [
          'Zucchini 2 (spiralised)',
          'Basil pesto 2 tbsp',
          'Cherry tomatoes 6',
          'Pine nuts 1 tsp',
          'Olive oil, sea salt'
        ],
        steps: [
          'Spiralise the zucchini and dry-sauté for 1 minute to remove water.',
          'Off the heat, toss with the pesto and add the tomatoes and pine nuts.'
        ],
        notes: 'Nut allergy? Skip the pine nuts. Vegan? Choose a pesto without parmesan.'
      },
      zh: {
        name: '西葫芦面青酱碗',
        time: '12 分钟',
        servings: '1 份',
        why: '用西葫芦替代意面，碳水大幅下降，青酱提供好脂肪。',
        ingredients: [
          '西葫芦 2 根（刨丝）',
          '罗勒青酱 2 汤匙',
          '小番茄 6 颗',
          '松子 1 茶匙',
          '橄榄油、海盐 适量'
        ],
        steps: [
          '西葫芦刨成面条，快速干煸 1 分钟去水。',
          '离火拌入青酱，加小番茄与松子。'
        ],
        notes: '坚果过敏者去掉松子；严格素食者选无帕玛森的纯素青酱。'
      },
      macros: {
        protein: {
          g: 8,
          pct: 18
        },
        fat: {
          g: 22,
          pct: 55
        },
        netCarbs: {
          g: 8,
          pct: 27
        }
      }
    },
    {
      id: 'l8',
      type: 'lunch',
      carb: 'low',
      tags: [
        'asian',
        'no-cook',
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish',
        'nuts'
      ],
      focus: [
        'Asian',
        'No-cook'
      ],
      img: 'vietnamese-chicken-salad.jpg',
      emoji: '🥗',
      en: {
        name: 'Vietnamese Chicken Salad',
        time: '15 min',
        servings: '2',
        why: 'Bright, tangy and no-cook — made with ready-cooked chicken. Especially good in summer.',
        ingredients: [
          'Cooked chicken breast 1 (shredded)',
          'Shredded cabbage 2 cups',
          'Grated carrot 1 cup',
          'Mint and coriander',
          'Fish sauce 1 tbsp',
          'Lime juice 2 tbsp',
          'Crushed peanuts 1 tbsp'
        ],
        steps: [
          'Mix the fish sauce and lime juice into a dressing.',
          'Toss everything in a large bowl with the dressing.',
          'Scatter over the peanuts just before serving.'
        ],
        notes: 'Nut allergy? Leave out the peanuts and use crisp fried shallots instead.'
      },
      zh: {
        name: '越式鸡肉沙拉',
        time: '15 分钟',
        servings: '2 份',
        why: '酸辣清爽、免烹，用现成烤鸡就能做，夏天尤其合适。',
        ingredients: [
          '熟鸡胸 1 块（撕丝）',
          '卷心菜丝 2 杯',
          '胡萝卜丝 1 杯',
          '薄荷、香菜 适量',
          '鱼露 1 汤匙',
          '青柠汁 2 汤匙',
          '花生碎 1 汤匙'
        ],
        steps: [
          '鱼露、青柠汁调成汁。',
          '所有食材放大碗，淋汁拌匀。',
          '上桌前撒花生碎。'
        ],
        notes: '坚果过敏者去掉花生，改用烤葱头。'
      },
      macros: {
        protein: {
          g: 30,
          pct: 45
        },
        fat: {
          g: 12,
          pct: 35
        },
        netCarbs: {
          g: 7,
          pct: 20
        }
      }
    },
    {
      id: 'l9',
      type: 'lunch',
      carb: 'moderate',
      tags: [
        'no-cook',
        'quick-easy',
        'vegetarian'
      ],
      contains: [
        'gluten'
      ],
      focus: [
        'Quick & easy',
        'Vegetarian'
      ],
      img: null,
      emoji: '🥪',
      en: {
        name: 'Chickpea Salad Sandwich',
        time: '10 min',
        servings: '2',
        why: 'A plant-based tuna-salad-style sandwich — high in fibre and protein.',
        ingredients: [
          'Chickpeas 1 tin (mashed)',
          'Celery 1 stalk (diced)',
          'Red onion 2 tbsp (finely diced)',
          'Vegan mayo 2 tbsp',
          'Lemon juice 1 tsp',
          'Wholegrain bread 4 slices',
          'Lettuce, tomato'
        ],
        steps: [
          'Mash the chickpeas with a fork, leaving some texture.',
          'Mix in celery, onion, mayo, lemon, salt and pepper.',
          'Build sandwiches with lettuce and tomato.'
        ],
        notes: 'Use gluten-free bread; for low-carb serve in lettuce cups.'
      },
      zh: {
        name: '鹰嘴豆沙拉三明治',
        time: '10 分钟',
        servings: '2 份',
        why: '植物版金枪鱼沙拉三明治，高纤维高蛋白。',
        ingredients: [
          '鹰嘴豆罐头 1 罐（压碎）',
          '芹菜 1 根（切丁）',
          '紫洋葱 2 汤匙（细丁）',
          '纯素蛋黄酱 2 汤匙',
          '柠檬汁 1 茶匙',
          '全麦面包 4 片',
          '生菜、番茄 适量'
        ],
        steps: [
          '鹰嘴豆用叉子压成带颗粒的泥。',
          '拌入芹菜、洋葱、蛋黄酱、柠檬、盐和胡椒。',
          '配生菜番茄夹成三明治。'
        ],
        notes: '无麸质用无麸质面包；低碳可用生菜杯。'
      },
      macros: {
        protein: {
          g: 14,
          pct: 25
        },
        fat: {
          g: 12,
          pct: 35
        },
        netCarbs: {
          g: 20,
          pct: 40
        }
      }
    },
    {
      id: 'l10',
      type: 'lunch',
      carb: 'low',
      tags: [
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'dairy'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: null,
      emoji: '🥗',
      en: {
        name: 'Chicken Caesar Salad',
        time: '12 min',
        servings: '1',
        why: 'Classic high-protein salad — use a lighter dressing to keep it gut-friendly.',
        ingredients: [
          'Grilled chicken breast 1',
          'Romaine lettuce 1 head',
          'Parmesan 2 tbsp (grated)',
          'Caesar dressing 2 tbsp (light)',
          'Cherry tomatoes 6',
          '(Optional) 1/2 wholegrain roll'
        ],
        steps: [
          'Slice the chicken. Wash and chop the romaine.',
          'Toss lettuce and tomatoes with dressing; top with chicken and parmesan.'
        ],
        notes: 'Use Greek yogurt dressing for a lighter version; skip croutons for low carb.'
      },
      zh: {
        name: '凯撒鸡肉沙拉',
        time: '12 分钟',
        servings: '1 份',
        why: '经典高蛋白沙拉，用清淡酱更肠道友好。',
        ingredients: [
          '烤鸡胸 1 块',
          '罗马生菜 1 颗',
          '帕玛森 2 汤匙（擦丝）',
          '凯撒酱 2 汤匙（低脂版）',
          '小番茄 6 颗',
          '（可选）半个全麦小面包'
        ],
        steps: [
          '鸡肉切片；生菜洗净切粗段。',
          '生菜与小番茄拌酱，铺鸡肉与帕玛森。'
        ],
        notes: '用希腊酸奶酱更清淡；低碳者不加面包丁。'
      },
      macros: {
        protein: {
          g: 32,
          pct: 45
        },
        fat: {
          g: 16,
          pct: 35
        },
        netCarbs: {
          g: 6,
          pct: 20
        }
      }
    },
    {
      id: 'l11',
      type: 'lunch',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'nuts'
      ],
      focus: [
        'Gut-healing',
        'Batch-cook'
      ],
      img: null,
      emoji: '🥙',
      en: {
        name: 'Quinoa Buddha Bowl',
        time: '25 min',
        servings: '2',
        why: 'A plant-powered bowl with complete protein, healthy fats and fibre.',
        ingredients: [
          'Quinoa 1 cup (dry)',
          'Chickpeas 1 tin',
          'Roasted sweet potato 1 cup',
          'Baby spinach 2 cups',
          'Tahini 2 tbsp + lemon juice',
          'Pumpkin seeds 1 tbsp'
        ],
        steps: [
          'Cook quinoa in 1:2 water for 15 minutes; roast sweet potato cubes at 200°C for 20 min.',
          'Build bowls: quinoa, chickpeas, sweet potato, spinach.',
          'Whisk tahini with lemon and water; drizzle and top with seeds.'
        ],
        notes: 'Roast a big batch of sweet potato — keeps 5 days for easy bowls.'
      },
      zh: {
        name: '藜麦佛碗',
        time: '25 分钟',
        servings: '2 份',
        why: '植物全餐，完整蛋白 + 好脂肪 + 纤维齐了。',
        ingredients: [
          '藜麦 1 杯（生）',
          '鹰嘴豆罐头 1 罐',
          '烤红薯块 1 杯',
          '嫩菠菜 2 杯',
          '芝麻酱 2 汤匙 + 柠檬汁',
          '南瓜籽 1 汤匙'
        ],
        steps: [
          '藜麦 1:2 水煮 15 分钟；红薯块 200°C 烤 20 分钟。',
          '装碗：藜麦、鹰嘴豆、红薯、菠菜。',
          '芝麻酱加柠檬与水搅稀，淋碗上撒南瓜籽。'
        ],
        notes: '红薯一次烤一大盘，可存 5 天随取随用。'
      },
      macros: {
        protein: {
          g: 14,
          pct: 22
        },
        fat: {
          g: 16,
          pct: 38
        },
        netCarbs: {
          g: 22,
          pct: 40
        }
      }
    },
    {
      id: 'l12',
      type: 'lunch',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish'
      ],
      focus: [
        'No-cook',
        'High protein'
      ],
      img: null,
      emoji: '🫑',
      en: {
        name: 'Tuna Salad Stuffed Peppers',
        time: '5 min',
        servings: '1',
        why: 'Crunchy bell pepper replaces bread — pure protein and produce.',
        ingredients: [
          'Bell peppers 2 (halved)',
          'Tuna in water 1 tin',
          'Avocado 1/2 (mashed)',
          'Red onion 1 tbsp (diced)',
          'Lemon juice 1 tbsp',
          'Sea salt, black pepper'
        ],
        steps: [
          'Halve and deseed the peppers.',
          'Mix tuna, mashed avocado, onion, lemon, salt and pepper.',
          'Spoon into pepper halves.'
        ],
        notes: 'Great for a packed lunch — no bread to get soggy.'
      },
      zh: {
        name: '金枪鱼沙拉酿彩椒',
        time: '5 分钟',
        servings: '1 份',
        why: '用彩椒代替面包，纯蛋白 + 蔬菜。',
        ingredients: [
          '彩椒 2 个（对半切）',
          '水浸金枪鱼 1 罐',
          '牛油果半个（压泥）',
          '紫洋葱 1 汤匙（切丁）',
          '柠檬汁 1 汤匙',
          '海盐、黑胡椒 适量'
        ],
        steps: [
          '彩椒对半切去籽。',
          '金枪鱼、牛油果、洋葱、柠檬、盐和胡椒拌匀。',
          '舀入彩椒中。'
        ],
        notes: '带饭很合适——没有面包会变软。'
      },
      macros: {
        protein: {
          g: 24,
          pct: 50
        },
        fat: {
          g: 10,
          pct: 35
        },
        netCarbs: {
          g: 4,
          pct: 15
        }
      }
    },
    {
      id: 'l13',
      type: 'lunch',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'high-protein',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'egg'
      ],
      focus: [
        'No-cook',
        'Quick & easy'
      ],
      img: null,
      emoji: '🥬',
      en: {
        name: 'Egg Salad Lettuce Wraps',
        time: '8 min',
        servings: '1',
        why: 'No bread, all protein — a five-minute lunch with healthy fats.',
        ingredients: [
          'Hard-boiled eggs 3 (chopped)',
          'Avocado mayo 2 tbsp',
          'Dijon mustard 1 tsp',
          'Celery 1 stalk (diced)',
          'Butter lettuce leaves 4',
          'Chives, sea salt'
        ],
        steps: [
          'Mash eggs with mayo, mustard, celery, chives and salt.',
          'Spoon into lettuce leaves.'
        ],
        notes: 'Use Greek yogurt instead of mayo for a lighter version.'
      },
      zh: {
        name: '鸡蛋沙拉生菜包',
        time: '8 分钟',
        servings: '1 份',
        why: '不加面包、纯蛋白，5 分钟午餐含好脂肪。',
        ingredients: [
          '水煮蛋 3 个（切丁）',
          '牛油果蛋黄酱 2 汤匙',
          '第戎芥末 1 茶匙',
          '芹菜 1 根（切丁）',
          '奶油生菜叶 4 片',
          '细香葱、海盐 适量'
        ],
        steps: [
          '鸡蛋与蛋黄酱、芥末、芹菜、香葱、盐压成粗粒。',
          '舀入生菜叶即可。'
        ],
        notes: '用希腊酸奶替代蛋黄酱更清淡。'
      },
      macros: {
        protein: {
          g: 18,
          pct: 40
        },
        fat: {
          g: 12,
          pct: 35
        },
        netCarbs: {
          g: 5,
          pct: 25
        }
      }
    },
    {
      id: 'l14',
      type: 'lunch',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Gut-healing',
        'Batch-cook'
      ],
      img: null,
      emoji: '🌿',
      en: {
        name: 'Lentil Tabbouleh',
        time: '20 min',
        servings: '4',
        why: 'Parsley and lentils bring fibre, iron and plant protein — a fresh, batch-friendly salad.',
        ingredients: [
          'Green or brown lentils 1 cup (cooked)',
          'Bulgur 1/2 cup (cooked) — or quinoa for GF',
          'Parsley 1 large bunch (chopped)',
          'Mint 1/4 cup',
          'Tomatoes 2 (diced)',
          'Lemon 1, olive oil 3 tbsp'
        ],
        steps: [
          'Cook lentils and bulgur separately until tender; cool.',
          'Mix with chopped herbs, tomatoes.',
          'Dress with lemon and olive oil; season.'
        ],
        notes: 'Use quinoa instead of bulgur for a gluten-free version.'
      },
      zh: {
        name: '扁豆塔布勒沙拉',
        time: '20 分钟',
        servings: '4 份',
        why: '欧芹和扁豆提供纤维、铁与植物蛋白，清爽可批量。',
        ingredients: [
          '绿扁豆 1 杯（煮熟）',
          '布格麦 1/2 杯（煮熟）—无麸质用藜麦',
          '欧芹 1 大把（切碎）',
          '薄荷 1/4 杯',
          '番茄 2 个（切丁）',
          '柠檬 1 个、橄榄油 3 汤匙'
        ],
        steps: [
          '扁豆与布格麦分别煮熟放凉。',
          '与欧芹、薄荷、番茄混合。',
          '加柠檬汁与橄榄油，调味即可。'
        ],
        notes: '无麸质用藜麦代替布格麦。'
      },
      macros: {
        protein: {
          g: 10,
          pct: 22
        },
        fat: {
          g: 8,
          pct: 30
        },
        netCarbs: {
          g: 20,
          pct: 48
        }
      }
    },
    {
      id: 'd1',
      type: 'dinner',
      carb: 'low',
      tags: [
        'quick-easy',
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish'
      ],
      focus: [
        'Quick & easy',
        'Batch-cook'
      ],
      img: 'sheet-pan-salmon-broccoli.jpg',
      emoji: '🐟',
      en: {
        name: 'Sheet-Pan Salmon & Broccoli',
        time: '25 min',
        servings: '2',
        why: 'One tray, almost no washing up — a low-carb, high-protein dinner template.',
        ingredients: [
          'Salmon 2 fillets',
          'Broccoli 1 head',
          'Lemon 1',
          'Olive oil 2 tbsp',
          'Garlic powder, sea salt, black pepper'
        ],
        steps: [
          'Heat the oven to 200°C. Toss the broccoli in oil and salt and spread on a tray.',
          'Roast 8 minutes, then add the salmon and roast 12 minutes more.',
          'Squeeze over lemon to finish.'
        ],
        notes: 'Roast an extra portion and take it for lunch the next day.'
      },
      zh: {
        name: '一盘烤三文鱼西兰花',
        time: '25 分钟',
        servings: '2 份',
        why: '一个烤盘搞定，几乎零清洗，低碳高蛋白的晚餐模板。',
        ingredients: [
          '三文鱼 2 块',
          '西兰花 1 颗',
          '柠檬 1 个',
          '橄榄油 2 汤匙',
          '蒜粉、海盐、黑胡椒 适量'
        ],
        steps: [
          '烤箱 200°C 预热；西兰花拌油盐铺盘。',
          '先烤 8 分钟，放入三文鱼再烤 12 分钟。',
          '出炉挤柠檬汁即可。'
        ],
        notes: '一次多烤一份，第二天午餐直接带。'
      },
      macros: {
        protein: {
          g: 30,
          pct: 45
        },
        fat: {
          g: 16,
          pct: 40
        },
        netCarbs: {
          g: 6,
          pct: 15
        }
      }
    },
    {
      id: 'd2',
      type: 'dinner',
      carb: 'moderate',
      tags: [
        'asian',
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'soy',
        'sesame'
      ],
      focus: [
        'Asian',
        'Quick & easy'
      ],
      img: 'chicken-stir-fry-bok-choy.jpg',
      emoji: '🥘',
      en: {
        name: 'Chicken Stir-Fry with Bok Choy',
        time: '18 min',
        servings: '2',
        why: 'An Asian one-pan dinner with plenty of vegetables and enough protein.',
        ingredients: [
          'Chicken thigh 300g (sliced)',
          'Bok choy 3 heads',
          'Garlic and ginger, 1 tsp each',
          'Gluten-free soy sauce (tamari) 1.5 tbsp',
          'Rice vinegar 1 tsp',
          'Sesame oil 1 tsp'
        ],
        steps: [
          'Heat the sesame oil and cook the chicken until it changes colour; set aside.',
          'Sauté the garlic and ginger, then stir-fry the bok choy.',
          'Return the chicken, add the tamari and vinegar, and toss to finish.'
        ],
        notes: 'Serve with brown rice for moderate carb, or cauliflower rice for low carb.'
      },
      zh: {
        name: '小白菜炒鸡片',
        time: '18 分钟',
        servings: '2 份',
        why: '一锅到底的亚洲快手菜，蔬菜量足、蛋白够。',
        ingredients: [
          '鸡腿肉 300g（切片）',
          '小白菜 3 棵',
          '蒜末、姜末 各 1 茶匙',
          '无麸质生抽 (tamari) 1.5 汤匙',
          '米醋 1 茶匙',
          '芝麻油 1 茶匙'
        ],
        steps: [
          '热锅下麻油，鸡肉炒至变色盛出。',
          '炒香蒜姜，下小白菜快炒。',
          '回锅鸡肉，淋生抽与米醋翻匀出锅。'
        ],
        notes: '配糙米饭即中碳，配花菜饭即低碳。'
      },
      macros: {
        protein: {
          g: 32,
          pct: 40
        },
        fat: {
          g: 14,
          pct: 30
        },
        netCarbs: {
          g: 18,
          pct: 30
        }
      }
    },
    {
      id: 'd3',
      type: 'dinner',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'gut-healing',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Batch-cook',
        'Gut-healing'
      ],
      img: 'beef-veggie-chili.jpg',
      emoji: '🌶️',
      en: {
        name: 'Beef & Veggie Chili',
        time: '50 min',
        servings: '5',
        why: 'One pot makes five portions and improves with time — plenty of fibre and protein.',
        ingredients: [
          'Grass-fed beef mince 500g',
          'Tinned tomatoes 2 tins',
          'Kidney beans 1 tin',
          'Onion and bell pepper, 1 each',
          'Cumin, chilli powder, oregano, 1 tsp each',
          'Olive oil'
        ],
        steps: [
          'Brown the beef in olive oil until slightly crusted.',
          'Add the onion and pepper and soften, then stir in the spices.',
          'Add the tomatoes and beans and simmer 30 minutes; season.'
        ],
        notes: 'Keeps 5 days chilled, 3 months frozen. Serve with avocado or yogurt.'
      },
      zh: {
        name: '牛肉蔬菜辣豆汤',
        time: '50 分钟',
        servings: '5 份',
        why: '一锅炖五天份，越放越入味，纤维与蛋白都很足。',
        ingredients: [
          '草饲牛肉末 500g',
          '番茄罐头 2 罐',
          '芸豆 1 罐',
          '洋葱、彩椒 各 1 个',
          '孜然、辣椒粉、牛至 各 1 茶匙',
          '橄榄油'
        ],
        steps: [
          '橄榄油炒散牛肉末至微焦。',
          '加洋葱彩椒炒软，下香料炒香。',
          '加番茄与芸豆，小火炖 30 分钟调味。'
        ],
        notes: '冷藏 5 天、冷冻 3 个月；可配牛油果或酸奶。'
      },
      macros: {
        protein: {
          g: 30,
          pct: 35
        },
        fat: {
          g: 14,
          pct: 30
        },
        netCarbs: {
          g: 22,
          pct: 35
        }
      }
    },
    {
      id: 'd4',
      type: 'dinner',
      carb: 'moderate',
      tags: [
        'asian',
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish'
      ],
      focus: [
        'Asian',
        'Batch-cook'
      ],
      img: 'thai-coconut-curry.jpg',
      emoji: '🍛',
      en: {
        name: 'Thai Coconut Chicken Curry',
        time: '30 min',
        servings: '4',
        why: 'Coconut milk is gentle on the gut and the curry spices are anti-inflammatory. Batch-friendly.',
        ingredients: [
          'Chicken thigh 500g',
          'Coconut milk 1 tin',
          'Red curry paste 2 tbsp',
          'Bell pepper and onion, 1 each',
          'Fish sauce 1 tbsp',
          'Lime, basil'
        ],
        steps: [
          'Fry the curry paste in a little coconut milk until fragrant.',
          'Add the chicken and brown, then pour in the rest of the coconut milk.',
          'Add the vegetables and simmer 15 minutes; season with fish sauce and lime, then add basil.'
        ],
        notes: 'Serve with cauliflower rice for low carb. Keeps 4 days chilled.'
      },
      zh: {
        name: '泰式椰香咖喱鸡',
        time: '30 分钟',
        servings: '4 份',
        why: '椰奶温和不刺激，咖喱香料助抗炎，一锅可备餐。',
        ingredients: [
          '鸡腿肉 500g',
          '椰奶 1 罐',
          '红咖喱酱 2 汤匙',
          '彩椒、洋葱 各 1 个',
          '鱼露 1 汤匙',
          '青柠、罗勒 适量'
        ],
        steps: [
          '咖喱酱用少量椰奶炒香。',
          '加鸡肉块炒上色，倒入剩余椰奶。',
          '加蔬菜炖 15 分钟，用鱼露与青柠调味，撒罗勒。'
        ],
        notes: '配花菜饭为低碳版；冷藏 4 天。'
      },
      macros: {
        protein: {
          g: 30,
          pct: 35
        },
        fat: {
          g: 20,
          pct: 35
        },
        netCarbs: {
          g: 18,
          pct: 30
        }
      }
    },
    {
      id: 'd5',
      type: 'dinner',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Batch-cook',
        'High protein'
      ],
      img: 'herb-roasted-chicken-root-veg.jpg',
      emoji: '🍗',
      en: {
        name: 'Herb Roasted Chicken & Root Veg',
        time: '50 min',
        servings: '4',
        why: 'Roast one tray at the weekend and you have protein all week; root veg brings slow carbs and fibre.',
        ingredients: [
          'Chicken thighs 4',
          'Carrot, sweet potato, onion, as needed',
          'Rosemary and thyme, 1 tsp each',
          'Olive oil 3 tbsp',
          'Sea salt, black pepper'
        ],
        steps: [
          'Toss the chopped vegetables and chicken in oil and herbs; spread on a tray.',
          'Roast at 200°C for 45 minutes until the skin is golden.',
          'Rest 5 minutes before serving.'
        ],
        notes: 'Swap sweet potato for cauliflower for a low-carb version.'
      },
      zh: {
        name: '香草烤鸡配根茎菜',
        time: '50 分钟',
        servings: '4 份',
        why: '周末烤一盘，全周有蛋白；根茎菜提供慢碳与纤维。',
        ingredients: [
          '鸡腿 4 只',
          '胡萝卜、红薯、洋葱 各适量',
          '迷迭香、百里香 各 1 茶匙',
          '橄榄油 3 汤匙',
          '海盐、黑胡椒'
        ],
        steps: [
          '蔬菜切块与鸡腿拌油与香草，铺烤盘。',
          '200°C 烤 45 分钟至鸡皮金黄。',
          '静置 5 分钟再上桌。'
        ],
        notes: '红薯换成花菜即为低碳版。'
      },
      macros: {
        protein: {
          g: 35,
          pct: 40
        },
        fat: {
          g: 18,
          pct: 30
        },
        netCarbs: {
          g: 22,
          pct: 30
        }
      }
    },
    {
      id: 'd6',
      type: 'dinner',
      carb: 'low',
      tags: [
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'shellfish'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: 'garlic-shrimp-zoodles.jpg',
      emoji: '🍤',
      en: {
        name: 'Garlic Shrimp Zoodles',
        time: '15 min',
        servings: '2',
        why: 'A 15-minute low-carb dinner: shrimp are high protein and low fat, and the garlic is appetising.',
        ingredients: [
          'Shrimp 300g',
          'Zucchini 2 (spiralised)',
          'Garlic 3 cloves (minced)',
          'Olive oil 2 tbsp',
          'Chilli flakes, lemon, sea salt'
        ],
        steps: [
          'Heat the olive oil and infuse the garlic and chilli flakes.',
          'Add the shrimp and cook until pink, then add the zoodles and toss 1 minute.',
          'Squeeze over lemon and season.'
        ],
        notes: 'Shellfish allergy? Use chicken breast. Do not overcook the zoodles — they release water.'
      },
      zh: {
        name: '蒜香虾仁西葫芦面',
        time: '15 分钟',
        servings: '2 份',
        why: '15 分钟低碳晚餐，虾仁高蛋白低脂，蒜香开胃。',
        ingredients: [
          '虾仁 300g',
          '西葫芦 2 根（刨丝）',
          '蒜末 3 瓣',
          '橄榄油 2 汤匙',
          '辣椒碎、柠檬、海盐 适量'
        ],
        steps: [
          '橄榄油爆香蒜末与辣椒碎。',
          '下虾仁炒至变粉，加西葫芦面快炒 1 分钟。',
          '挤柠檬汁，调味出锅。'
        ],
        notes: '贝类过敏者换鸡胸；西葫芦面别久炒，会出水。'
      },
      macros: {
        protein: {
          g: 28,
          pct: 50
        },
        fat: {
          g: 12,
          pct: 38
        },
        netCarbs: {
          g: 4,
          pct: 12
        }
      }
    },
    {
      id: 'd7',
      type: 'dinner',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Batch-cook',
        'High protein'
      ],
      img: 'turkey-stuffed-bell-peppers.jpg',
      emoji: '🫑',
      en: {
        name: 'Turkey Stuffed Bell Peppers',
        time: '45 min',
        servings: '4',
        why: 'One pepper per portion — freeze them ahead and reheat on a busy day.',
        ingredients: [
          'Bell peppers 4',
          'Turkey mince 400g',
          'Chopped tomatoes 1 cup',
          'Onion 1 (diced)',
          'Cumin and paprika, 1 tsp each',
          'Olive oil'
        ],
        steps: [
          'Core the peppers. Sauté the onion and turkey, then add the tomatoes and spices.',
          'Fill the peppers and bake at 200°C for 30 minutes.',
          'Rest 5 minutes before serving.'
        ],
        notes: 'Add a little brown rice for extra satiety. Keeps 4 days chilled, 2 months frozen.'
      },
      zh: {
        name: '火鸡酿彩椒',
        time: '45 分钟',
        servings: '4 份',
        why: '一人份一个，预制好冷冻，忙碌日直接加热。',
        ingredients: [
          '彩椒 4 个',
          '火鸡肉末 400g',
          '番茄碎 1 杯',
          '洋葱 1 个（切丁）',
          '孜然、红椒粉 各 1 茶匙',
          '橄榄油'
        ],
        steps: [
          '彩椒去籽；炒香洋葱与火鸡肉末，加番茄与香料。',
          '填入彩椒，200°C 烤 30 分钟。',
          '出炉静置 5 分钟。'
        ],
        notes: '可加少量糙米提升饱腹；冷藏 4 天、冷冻 2 个月。'
      },
      macros: {
        protein: {
          g: 28,
          pct: 38
        },
        fat: {
          g: 12,
          pct: 28
        },
        netCarbs: {
          g: 20,
          pct: 34
        }
      }
    },
    {
      id: 'd8',
      type: 'dinner',
      carb: 'low',
      tags: [
        'asian',
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish',
        'soy'
      ],
      focus: [
        'Asian',
        'High protein'
      ],
      img: 'miso-glazed-cod.jpg',
      emoji: '🐟',
      en: {
        name: 'Miso Glazed Cod with Greens',
        time: '20 min',
        servings: '2',
        why: 'Cod is very low fat and high protein; the miso glaze adds colour and depth. A low-carb dinner staple.',
        ingredients: [
          'Cod fillets 2',
          'White miso 1 tbsp (choose gluten-free)',
          'Mirin 1 tbsp',
          'Pak choi 3 heads',
          'Ginger, julienned 1 tsp',
          'Sesame oil 1 tsp'
        ],
        steps: [
          'Mix the miso and mirin and coat the cod; rest 10 minutes.',
          'Bake at 200°C for 12 minutes until the surface caramelises.',
          'Stir-fry the pak choi with sesame oil, garlic and ginger; plate with the fish.'
        ],
        notes: 'Choose gluten-free miso if needed.'
      },
      zh: {
        name: '味噌烤鳕鱼配青菜',
        time: '20 分钟',
        servings: '2 份',
        why: '鳕鱼极低脂高蛋白，味噌上色提味，低碳晚餐首选。',
        ingredients: [
          '鳕鱼排 2 块',
          '白味噌 1 汤匙（选无麸质）',
          '味醂 1 汤匙',
          '上海青 3 棵',
          '姜丝 1 茶匙',
          '芝麻油 1 茶匙'
        ],
        steps: [
          '味噌与味醂调匀抹在鳕鱼上，腌 10 分钟。',
          '200°C 烤 12 分钟至表面微焦。',
          '上海青用麻油蒜姜快炒，与鱼同盘。'
        ],
        notes: '无麸质者选无麸质味噌。'
      },
      macros: {
        protein: {
          g: 28,
          pct: 55
        },
        fat: {
          g: 8,
          pct: 30
        },
        netCarbs: {
          g: 4,
          pct: 15
        }
      }
    },
    {
      id: 'd9',
      type: 'dinner',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Batch-cook',
        'High protein'
      ],
      img: null,
      emoji: '🍠',
      en: {
        name: 'Sheet-Pan Chicken & Sweet Potato',
        time: '35 min',
        servings: '4',
        why: 'A one-pan batch-cook dinner — protein, slow carbs and fibre for the whole week.',
        ingredients: [
          'Chicken thighs 4',
          'Sweet potato 2 (cubed)',
          'Broccoli 1 head',
          'Olive oil 3 tbsp',
          'Smoked paprika, garlic powder, rosemary',
          'Sea salt, black pepper'
        ],
        steps: [
          'Toss everything in oil and spices on a tray.',
          'Roast at 220°C for 25–30 minutes until the chicken is golden and the potatoes are tender.'
        ],
        notes: 'Make double — portion into containers for 4 lunches.'
      },
      zh: {
        name: '一盘烤鸡红薯',
        time: '35 分钟',
        servings: '4 份',
        why: '一锅备餐晚餐，蛋白 + 慢碳 + 纤维，一周备齐。',
        ingredients: [
          '鸡腿 4 只',
          '红薯 2 个（切块）',
          '西兰花 1 颗',
          '橄榄油 3 汤匙',
          '烟熏红椒粉、蒜粉、迷迭香 适量',
          '海盐、黑胡椒 适量'
        ],
        steps: [
          '所有食材拌油与香料铺烤盘。',
          '220°C 烤 25–30 分钟至鸡腿金黄、红薯软糯。'
        ],
        notes: '做双份，分装 4 份午餐。'
      },
      macros: {
        protein: {
          g: 35,
          pct: 38
        },
        fat: {
          g: 12,
          pct: 26
        },
        netCarbs: {
          g: 26,
          pct: 36
        }
      }
    },
    {
      id: 'd10',
      type: 'dinner',
      carb: 'low',
      tags: [
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish',
        'dairy'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: null,
      emoji: '🐟',
      en: {
        name: 'Garlic Butter Salmon',
        time: '15 min',
        servings: '2',
        why: 'A 15-minute low-carb dinner with omega-3s and healthy fats.',
        ingredients: [
          'Salmon fillets 2',
          'Garlic 3 cloves (minced)',
          'Butter 2 tbsp',
          'Lemon 1',
          'Parsley 1 tbsp',
          'Asparagus or green beans to serve'
        ],
        steps: [
          'Pan-sear the salmon skin-down 4 minutes; flip and cook 3 more.',
          'Add butter and garlic; baste the fish for 1 minute.',
          'Finish with lemon juice and parsley; serve with greens.'
        ],
        notes: 'Use ghee for a dairy-light version.'
      },
      zh: {
        name: '蒜香黄油三文鱼',
        time: '15 分钟',
        servings: '2 份',
        why: '15 分钟低碳晚餐，Omega-3 与好脂肪齐了。',
        ingredients: [
          '三文鱼 2 块',
          '蒜末 3 瓣',
          '黄油 2 汤匙',
          '柠檬 1 个',
          '欧芹 1 汤匙',
          '芦笋或四季豆 适量'
        ],
        steps: [
          '三文鱼皮朝下煎 4 分钟，翻面再煎 3 分钟。',
          '加黄油与蒜末，浇汁 1 分钟。',
          '淋柠檬汁撒欧芹，配青菜。'
        ],
        notes: '用澄清黄油（ghee）更清淡。'
      },
      macros: {
        protein: {
          g: 32,
          pct: 50
        },
        fat: {
          g: 14,
          pct: 35
        },
        netCarbs: {
          g: 4,
          pct: 15
        }
      }
    },
    {
      id: 'd11',
      type: 'dinner',
      carb: 'low',
      tags: [
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'egg'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: null,
      emoji: '🍝',
      en: {
        name: 'Turkey Meatballs with Zoodles',
        time: '25 min',
        servings: '2',
        why: 'Lean turkey meatballs on zucchini noodles — comfort food without the carb crash.',
        ingredients: [
          'Turkey mince 400g',
          'Egg 1',
          'Almond flour 2 tbsp',
          'Garlic 2 cloves, oregano 1 tsp',
          'Zucchini 3 (spiralised)',
          'Sugar-free marinara 1 cup',
          'Olive oil'
        ],
        steps: [
          'Mix turkey, egg, almond flour, garlic and seasoning; roll into meatballs.',
          'Brown in olive oil; add marinara and simmer 10 minutes.',
          'Serve over zoodles (quick-sauté 1 minute).'
        ],
        notes: 'Use ground chicken if preferred. Pork works too.'
      },
      zh: {
        name: '火鸡肉丸西葫芦面',
        time: '25 分钟',
        servings: '2 份',
        why: '瘦火鸡肉丸配西葫芦面，安慰食物不带碳水崩盘。',
        ingredients: [
          '火鸡肉末 400g',
          '鸡蛋 1 个',
          '杏仁粉 2 汤匙',
          '蒜末 2 瓣、牛至 1 茶匙',
          '西葫芦 3 根（刨丝）',
          '无糖番茄酱 1 杯',
          '橄榄油 适量'
        ],
        steps: [
          '火鸡肉、蛋、杏仁粉、蒜和调味混合，搓成丸子。',
          '橄榄油煎至微焦，加番茄酱炖 10 分钟。',
          '配西葫芦面（快炒 1 分钟）。'
        ],
        notes: '可换鸡肉末；猪肉末亦可。'
      },
      macros: {
        protein: {
          g: 30,
          pct: 50
        },
        fat: {
          g: 12,
          pct: 35
        },
        netCarbs: {
          g: 4,
          pct: 15
        }
      }
    },
    {
      id: 'd12',
      type: 'dinner',
      carb: 'low',
      tags: [
        'asian',
        'quick-easy',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'soy',
        'sesame'
      ],
      focus: [
        'Asian',
        'Vegan'
      ],
      img: null,
      emoji: '🥡',
      en: {
        name: 'Vegetable Stir-Fry with Tofu',
        time: '20 min',
        servings: '2',
        why: 'A plant-based Asian dinner — tofu adds protein, vegetables add fibre.',
        ingredients: [
          'Firm tofu 300g (cubed)',
          'Broccoli 1 head',
          'Bell pepper 1',
          'Mushrooms 100g',
          'Garlic and ginger, 1 tsp each',
          'Gluten-free tamari 2 tbsp',
          'Sesame oil 1 tsp'
        ],
        steps: [
          'Press and cube the tofu; pan-fry until golden.',
          'Stir-fry garlic and ginger, then vegetables; return the tofu.',
          'Add tamari and sesame oil; toss to finish.'
        ],
        notes: 'Press tofu 15 min for best texture. Add chilli if you like heat.'
      },
      zh: {
        name: '豆腐蔬菜炒',
        time: '20 分钟',
        servings: '2 份',
        why: '亚洲植物晚餐，豆腐补蛋白，蔬菜补纤维。',
        ingredients: [
          '老豆腐 300g（切块）',
          '西兰花 1 颗',
          '彩椒 1 个',
          '蘑菇 100g',
          '蒜末、姜末 各 1 茶匙',
          '无麸质生抽 2 汤匙',
          '芝麻油 1 茶匙'
        ],
        steps: [
          '豆腐压水切丁，煎至金黄。',
          '炒香蒜姜，下蔬菜快炒，回锅豆腐。',
          '加生抽与芝麻油翻匀出锅。'
        ],
        notes: '豆腐压 15 分钟口感更好；喜辣可加辣椒。'
      },
      macros: {
        protein: {
          g: 18,
          pct: 35
        },
        fat: {
          g: 14,
          pct: 35
        },
        netCarbs: {
          g: 8,
          pct: 30
        }
      }
    },
    {
      id: 'd13',
      type: 'dinner',
      carb: 'low',
      tags: [
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'fish'
      ],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: null,
      emoji: '🐟',
      en: {
        name: 'Lemon Herb Cod',
        time: '20 min',
        servings: '2',
        why: 'A 20-minute low-fat, high-protein dinner — bright with lemon, fresh with herbs.',
        ingredients: [
          'Cod fillets 2',
          'Lemon 1',
          'Garlic 2 cloves (minced)',
          'Olive oil 1 tbsp',
          'Dill or parsley 2 tbsp',
          'Green beans or asparagus to serve'
        ],
        steps: [
          'Pat the cod dry; season. Heat oil and garlic in a pan.',
          'Sear the cod 3 minutes per side until flaky.',
          'Finish with lemon juice and herbs; serve with greens.'
        ],
        notes: 'Use haddock or any white fish. Avoid overcooking.'
      },
      zh: {
        name: '柠檬香草鳕鱼',
        time: '20 分钟',
        servings: '2 份',
        why: '20 分钟低脂高蛋白晚餐，柠檬清新、香草提味。',
        ingredients: [
          '鳕鱼排 2 块',
          '柠檬 1 个',
          '蒜末 2 瓣',
          '橄榄油 1 汤匙',
          '莳萝或欧芹 2 汤匙',
          '四季豆或芦笋 适量'
        ],
        steps: [
          '鳕鱼擦干调味；锅里热油加蒜。',
          '下鳕鱼每面煎 3 分钟至酥。',
          '淋柠檬汁撒香草，配青菜。'
        ],
        notes: '可用黑线鳕或任何白肉鱼；别过熟。'
      },
      macros: {
        protein: {
          g: 30,
          pct: 55
        },
        fat: {
          g: 8,
          pct: 30
        },
        netCarbs: {
          g: 4,
          pct: 15
        }
      }
    },
    {
      id: 'd14',
      type: 'dinner',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Batch-cook',
        'High protein'
      ],
      img: null,
      emoji: '🍖',
      en: {
        name: 'Slow Cooker Pulled Pork',
        time: '8 hours (slow cooker)',
        servings: '6',
        why: 'Effortless batch protein — perfect for tacos, bowls or lettuce wraps all week.',
        ingredients: [
          'Pork shoulder 1.5 kg',
          'Smoked paprika, cumin, garlic powder 1 tbsp each',
          'Apple cider vinegar 2 tbsp',
          'Sea salt, black pepper',
          'Sugar-free BBQ sauce 1/2 cup'
        ],
        steps: [
          'Rub the pork with spices; place in the slow cooker with vinegar.',
          'Cook on low 8 hours until it shreds easily.',
          'Shred with two forks; stir in BBQ sauce.'
        ],
        notes: 'Freezes 3 months. Serve with cauliflower rice or in lettuce wraps.'
      },
      zh: {
        name: '慢炖手撕猪肉',
        time: '8 小时（慢炖锅）',
        servings: '6 份',
        why: '零费力批量蛋白，一周做塔可、碗餐或生菜包都行。',
        ingredients: [
          '猪肩肉 1.5 kg',
          '烟熏红椒粉、孜然、蒜粉 各 1 汤匙',
          '苹果醋 2 汤匙',
          '海盐、黑胡椒 适量',
          '无糖烧烤酱 1/2 杯'
        ],
        steps: [
          '猪肉抹香料，放入慢炖锅加醋。',
          '低温炖 8 小时至轻松撕散。',
          '用两把叉子撕碎，拌入烧烤酱。'
        ],
        notes: '可冷冻 3 个月；配花菜饭或生菜包吃。'
      },
      macros: {
        protein: {
          g: 32,
          pct: 35
        },
        fat: {
          g: 18,
          pct: 32
        },
        netCarbs: {
          g: 18,
          pct: 33
        }
      }
    },
    {
      id: 'd15',
      type: 'dinner',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'nuts'
      ],
      focus: [
        'Batch-cook',
        'Vegan'
      ],
      img: null,
      emoji: '🎃',
      en: {
        name: 'Stuffed Acorn Squash',
        time: '50 min',
        servings: '2',
        why: 'A plant-based centerpiece — squash is fibre-rich and the quinoa filling is complete protein.',
        ingredients: [
          'Acorn squash 1 (halved)',
          'Quinoa 1/2 cup (dry)',
          'Cranberries 2 tbsp',
          'Pecans 2 tbsp (chopped)',
          'Olive oil 1 tbsp',
          'Sage, thyme, sea salt'
        ],
        steps: [
          'Roast squash halves face-down at 200°C for 30 minutes.',
          'Cook quinoa; mix with cranberries, pecans, herbs and oil.',
          'Flip squash, fill and bake 15 more minutes.'
        ],
        notes: 'Use any winter squash. Toast the pecans for more flavour.'
      },
      zh: {
        name: '藜麦酿橡子南瓜',
        time: '50 分钟',
        servings: '2 份',
        why: '植物主菜，南瓜高纤维，藜麦填料是完整蛋白。',
        ingredients: [
          '橡子南瓜 1 个（对半切）',
          '藜麦 1/2 杯（生）',
          '蔓越莓干 2 汤匙',
          '碧根果 2 汤匙（切碎）',
          '橄榄油 1 汤匙',
          '鼠尾草、百里香、海盐 适量'
        ],
        steps: [
          '南瓜切面朝下 200°C 烤 30 分钟。',
          '藜麦煮熟，与蔓越莓、碧根果、香草、油拌匀。',
          '南瓜翻面，填入藜麦再烤 15 分钟。'
        ],
        notes: '任何冬南瓜都行；碧根果烤一下更香。'
      },
      macros: {
        protein: {
          g: 10,
          pct: 18
        },
        fat: {
          g: 14,
          pct: 38
        },
        netCarbs: {
          g: 22,
          pct: 44
        }
      }
    },
    {
      id: 'd16',
      type: 'dinner',
      carb: 'low',
      tags: [
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Quick & easy',
        'High protein'
      ],
      img: null,
      emoji: '🌮',
      en: {
        name: 'Turkey Taco Skillet',
        time: '15 min',
        servings: '2',
        why: 'A 15-minute one-pan dinner — Mexican flavour without the wrap carbs.',
        ingredients: [
          'Turkey mince 400g',
          'Bell pepper 1 (diced)',
          'Onion 1/2 (diced)',
          'Taco seasoning 2 tbsp',
          'Diced tomatoes 1 cup',
          'Avocado 1 to serve',
          'Lime, cilantro'
        ],
        steps: [
          'Sauté onion and pepper; add turkey and brown.',
          'Stir in seasoning and tomatoes; simmer 5 minutes.',
          'Serve in bowls topped with avocado, lime and cilantro.'
        ],
        notes: 'Add cauliflower rice for more bulk without carbs.'
      },
      zh: {
        name: '火鸡塔可锅',
        time: '15 分钟',
        servings: '2 份',
        why: '15 分钟一锅晚餐，墨西哥风味，不包饼皮少碳水。',
        ingredients: [
          '火鸡肉末 400g',
          '彩椒 1 个（切丁）',
          '洋葱半个（切丁）',
          '塔可调味 2 汤匙',
          '番茄丁 1 杯',
          '牛油果 1 个',
          '青柠、香菜 适量'
        ],
        steps: [
          '炒香洋葱彩椒，加火鸡肉末炒散。',
          '加调味与番茄，炖 5 分钟。',
          '装碗铺牛油果、青柠与香菜。'
        ],
        notes: '加花菜米更饱腹不升碳。'
      },
      macros: {
        protein: {
          g: 28,
          pct: 45
        },
        fat: {
          g: 14,
          pct: 35
        },
        netCarbs: {
          g: 6,
          pct: 20
        }
      }
    },
    {
      id: 's1',
      type: 'snack',
      carb: 'moderate',
      tags: [
        'no-cook',
        'quick-easy',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'nuts'
      ],
      focus: [
        'No-cook',
        'Quick & easy'
      ],
      img: 'apple-almond-butter.jpg',
      emoji: '🍎',
      en: {
        name: 'Apple Slices & Almond Butter',
        time: '2 min',
        servings: '1',
        why: 'Fibre plus healthy fat — a golden combination that slows the blood-sugar rise.',
        ingredients: [
          'Apple 1',
          'Unsweetened almond butter 1 tbsp',
          'Cinnamon, a pinch'
        ],
        steps: [
          'Slice the apple, dip in the almond butter and dust with cinnamon.'
        ],
        notes: 'Nut allergy? Use sunflower seed butter.'
      },
      zh: {
        name: '苹果片配杏仁酱',
        time: '2 分钟',
        servings: '1 份',
        why: '纤维 + 好脂肪的黄金组合，延缓血糖上升，解馋又稳。',
        ingredients: [
          '苹果 1 个',
          '无糖杏仁酱 1 汤匙',
          '肉桂粉 少许'
        ],
        steps: [
          '苹果切片，蘸杏仁酱，撒肉桂粉。'
        ],
        notes: '坚果过敏者可换葵花籽酱。'
      },
      macros: {
        protein: {
          g: 4,
          pct: 8
        },
        fat: {
          g: 16,
          pct: 60
        },
        netCarbs: {
          g: 14,
          pct: 32
        }
      }
    },
    {
      id: 's2',
      type: 'snack',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'batch-cook',
        'high-protein',
        'gluten-free'
      ],
      contains: [
        'egg'
      ],
      focus: [
        'Batch-cook',
        'High protein'
      ],
      img: 'hard-boiled-eggs.jpg',
      emoji: '🥚',
      en: {
        name: 'Hard-Boiled Eggs & Sea Salt',
        time: '12 min (batch-friendly)',
        servings: '4',
        why: 'The simplest low-carb, high-protein snack. Boil a dozen and keep them in the fridge.',
        ingredients: [
          'Eggs 4–12',
          'Sea salt, black pepper'
        ],
        steps: [
          'Start in cold water; once boiling, cook 7 minutes (soft) or 10 (firm).',
          'Cool in iced water, peel, and season with salt.'
        ],
        notes: 'Keeps a week chilled — a zero-cost batch-cook option.'
      },
      zh: {
        name: '海盐溏心蛋',
        time: '12 分钟（可批量）',
        servings: '4 份',
        why: '最省事的低碳高蛋白零食，一次煮一打放冰箱随取。',
        ingredients: [
          '鸡蛋 4–12 个',
          '海盐、黑胡椒 适量'
        ],
        steps: [
          '冷水下蛋，水开后煮 7 分钟（溏心）或 10 分钟（全熟）。',
          '冰水冷却后剥壳，撒盐即可。'
        ],
        notes: '冷藏可存 1 周，是 batch-cook 的零成本选项。'
      },
      macros: {
        protein: {
          g: 6,
          pct: 30
        },
        fat: {
          g: 5,
          pct: 50
        },
        netCarbs: {
          g: 1,
          pct: 20
        }
      }
    },
    {
      id: 's3',
      type: 'snack',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Gut-healing',
        'No-cook'
      ],
      img: 'veggie-sticks-guacamole.jpg',
      emoji: '🥑',
      en: {
        name: 'Veggie Sticks & Guacamole',
        time: '8 min',
        servings: '2',
        why: 'Low-carb, no-cook and high in fibre — veggie sticks replace crisps for that crunch.',
        ingredients: [
          'Cucumber, carrot, bell pepper, as needed',
          'Avocado 1',
          'Lime juice 1 tbsp',
          'Red onion, finely diced 1 tbsp',
          'Sea salt, coriander'
        ],
        steps: [
          'Mash the avocado with lime, onion, coriander and salt.',
          'Cut the vegetables into sticks and dip.'
        ],
        notes: 'Press cling film onto the guacamole to stop it browning.'
      },
      zh: {
        name: '蔬菜条配牛油果酱',
        time: '8 分钟',
        servings: '2 份',
        why: '低碳、免烹、纤维足，用蔬菜条代替薯片满足咀嚼欲。',
        ingredients: [
          '黄瓜、胡萝卜、彩椒 各适量',
          '牛油果 1 个',
          '青柠汁 1 汤匙',
          '红洋葱碎 1 汤匙',
          '海盐、香菜 适量'
        ],
        steps: [
          '牛油果压泥，拌青柠汁、洋葱、香菜与盐。',
          '蔬菜切条，蘸食即可。'
        ],
        notes: '牛油果酱表面盖保鲜膜贴面冷藏，防氧化变黑。'
      },
      macros: {
        protein: {
          g: 3,
          pct: 8
        },
        fat: {
          g: 12,
          pct: 60
        },
        netCarbs: {
          g: 6,
          pct: 32
        }
      }
    },
    {
      id: 's4',
      type: 'snack',
      carb: 'moderate',
      tags: [
        'no-cook',
        'quick-easy',
        'gut-healing',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'dairy',
        'nuts'
      ],
      focus: [
        'Gut-healing',
        'No-cook'
      ],
      img: 'greek-yogurt-honey-walnuts.jpg',
      emoji: '🍯',
      en: {
        name: 'Greek Yogurt with Honey & Walnuts',
        time: '3 min',
        servings: '1',
        why: 'Probiotics plus omega-3s, with sweetness from honey — far better than a dessert.',
        ingredients: [
          'Greek yogurt 150g',
          'Walnuts 2 (crushed)',
          'Raw honey 1 tsp',
          'Cinnamon, a pinch'
        ],
        steps: [
          'Spoon the yogurt into a bowl; add the walnuts and cinnamon and drizzle with honey.'
        ],
        notes: 'Watching sugar closely? Use extra cinnamon instead of honey.'
      },
      zh: {
        name: '希腊酸奶蜂蜜核桃',
        time: '3 分钟',
        servings: '1 份',
        why: '益生菌 + Omega-3，甜味来自蜂蜜，比甜点健康得多。',
        ingredients: [
          '希腊酸奶 150g',
          '核桃 2 颗（掰碎）',
          '生蜂蜜 1 茶匙',
          '肉桂粉 少许'
        ],
        steps: [
          '酸奶入碗，撒核桃与肉桂，淋蜂蜜。'
        ],
        notes: '控糖严格者可用肉桂代替蜂蜜。'
      },
      macros: {
        protein: {
          g: 10,
          pct: 18
        },
        fat: {
          g: 8,
          pct: 38
        },
        netCarbs: {
          g: 14,
          pct: 44
        }
      }
    },
    {
      id: 's5',
      type: 'snack',
      carb: 'moderate',
      tags: [
        'batch-cook',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Batch-cook',
        'Vegan'
      ],
      img: 'roasted-chickpeas.jpg',
      emoji: '🫘',
      en: {
        name: 'Crispy Roasted Chickpeas',
        time: '35 min',
        servings: '4',
        why: 'Crunchy enough to replace crisps, with good fibre and plant protein.',
        ingredients: [
          'Chickpeas 1 tin (drained and dried)',
          'Olive oil 1 tbsp',
          'Cumin, paprika, sea salt'
        ],
        steps: [
          'Dry the chickpeas thoroughly and toss with oil and spices.',
          'Roast at 200°C for 30 minutes, shaking halfway.',
          'They crisp up further as they cool.'
        ],
        notes: 'Keeps a week in an airtight jar. The drier they are, the crunchier they get.'
      },
      zh: {
        name: '香烤鹰嘴豆',
        time: '35 分钟',
        servings: '4 份',
        why: '烤脆后当零食，纤维与植物蛋白高，替代薯片。',
        ingredients: [
          '鹰嘴豆 1 罐（沥干擦干）',
          '橄榄油 1 汤匙',
          '孜然、红椒粉、海盐 各适量'
        ],
        steps: [
          '鹰嘴豆彻底擦干，拌油与香料。',
          '200°C 烤 30 分钟，中途摇匀。',
          '出炉后放凉会更脆。'
        ],
        notes: '密封罐存 1 周；擦得越干越脆。'
      },
      macros: {
        protein: {
          g: 6,
          pct: 20
        },
        fat: {
          g: 5,
          pct: 30
        },
        netCarbs: {
          g: 14,
          pct: 50
        }
      }
    },
    {
      id: 's6',
      type: 'snack',
      carb: 'moderate',
      tags: [
        'asian',
        'quick-easy',
        'high-protein',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'soy'
      ],
      focus: [
        'Asian',
        'High protein'
      ],
      img: 'edamame-sea-salt.jpg',
      emoji: '🫛',
      en: {
        name: 'Edamame with Sea Salt',
        time: '6 min',
        servings: '2',
        why: 'Plant protein and fibre — and shelling them slows the pace of eating.',
        ingredients: [
          'Frozen edamame 2 cups',
          'Sea salt 1 tsp',
          '(Optional) garlic powder, chilli flakes'
        ],
        steps: [
          'Boil the edamame 4–5 minutes, drain and sprinkle with salt.'
        ],
        notes: 'Buy them in the pod — it feels more like a snack.'
      },
      zh: {
        name: '海盐毛豆',
        time: '6 分钟',
        servings: '2 份',
        why: '植物蛋白 + 纤维，剥壳过程还能放慢进食速度。',
        ingredients: [
          '冷冻毛豆 2 杯',
          '海盐 1 茶匙',
          '（可选）蒜粉、辣椒碎'
        ],
        steps: [
          '毛豆煮 4–5 分钟，沥干撒盐即可。'
        ],
        notes: '买带壳的更有"吃零食"的仪式感。'
      },
      macros: {
        protein: {
          g: 11,
          pct: 38
        },
        fat: {
          g: 5,
          pct: 30
        },
        netCarbs: {
          g: 8,
          pct: 32
        }
      }
    },
    {
      id: 's7',
      type: 'snack',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'high-protein',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'No-cook',
        'High protein'
      ],
      img: 'beef-jerky.jpg',
      emoji: '🥩',
      en: {
        name: 'Sugar-Free Beef Jerky',
        time: '2 min',
        servings: '1',
        why: 'Pure protein, low carb — the most convenient option when out and about.',
        ingredients: [
          'Sugar-free beef jerky 30g (choose nitrate-free)'
        ],
        steps: [
          'Eat as is; a glass of water makes it more filling.'
        ],
        notes: 'Read the label — many jerkies contain sugar or soy sauce (gluten).'
      },
      zh: {
        name: '无糖牛肉干',
        time: '2 分钟',
        servings: '1 份',
        why: '纯蛋白低碳零食，出门/开车时最方便的选择。',
        ingredients: [
          '无糖牛肉干 30g（选无亚硝酸盐、无麸质款）'
        ],
        steps: [
          '直接食用；配一杯水更饱。'
        ],
        notes: '注意看配料表，很多牛肉干含糖或酱油（麸质）。'
      },
      macros: {
        protein: {
          g: 18,
          pct: 75
        },
        fat: {
          g: 2,
          pct: 15
        },
        netCarbs: {
          g: 2,
          pct: 10
        }
      }
    },
    {
      id: 's8',
      type: 'snack',
      carb: 'moderate',
      tags: [
        'no-cook',
        'batch-cook',
        'gut-healing',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [],
      focus: [
        'Gut-healing',
        'Batch-cook'
      ],
      img: 'chia-coconut-pudding.jpg',
      emoji: '🥥',
      en: {
        name: 'Chia Coconut Pudding Cup',
        time: '5 min + chill',
        servings: '3',
        why: 'Make several cups ahead — high in fibre and filling. A great afternoon-tea substitute.',
        ingredients: [
          'Chia seeds 3 tbsp',
          'Unsweetened coconut milk 300ml',
          'Vanilla extract, a few drops',
          'Berries to top'
        ],
        steps: [
          'Stir the chia into the coconut milk and stir again after a few minutes.',
          'Divide into cups and chill at least 4 hours.',
          'Top with berries before serving.'
        ],
        notes: 'Keeps 4 days chilled — a good batch-cook snack.'
      },
      zh: {
        name: '奇亚椰奶杯',
        time: '5 分钟 + 冷藏',
        servings: '3 份',
        why: '可提前做几杯冷藏，纤维丰富、饱腹感强，下午茶替代品。',
        ingredients: [
          '奇亚籽 3 汤匙',
          '无糖椰奶 300ml',
          '香草精 数滴',
          '莓果 点缀'
        ],
        steps: [
          '奇亚籽与椰奶搅匀，静置后再搅一次。',
          '分装入杯，冷藏 4 小时以上。',
          '食用前加莓果。'
        ],
        notes: '冷藏 4 天；是 batch-cook 加餐的好例子。'
      },
      macros: {
        protein: {
          g: 4,
          pct: 12
        },
        fat: {
          g: 10,
          pct: 50
        },
        netCarbs: {
          g: 10,
          pct: 38
        }
      }
    },
    {
      id: 's9',
      type: 'snack',
      carb: 'moderate',
      tags: [
        'no-cook',
        'quick-easy',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'nuts'
      ],
      focus: [
        'No-cook',
        'Quick & easy'
      ],
      img: null,
      emoji: '🥜',
      en: {
        name: 'Trail Mix',
        time: '2 min',
        servings: '1',
        why: 'A balanced handful of nuts, seeds and a touch of dark chocolate.',
        ingredients: [
          'Almonds 2 tbsp',
          'Pumpkin seeds 1 tbsp',
          'Dried cranberries 1 tbsp',
          'Dark chocolate chips 1 tsp (70%+)'
        ],
        steps: [
          'Mix together; portion into small jars.'
        ],
        notes: 'Keep portions small — nuts are calorie-dense. Make a week of jars at once.'
      },
      zh: {
        name: '综合果仁能量混合',
        time: '2 分钟',
        servings: '1 份',
        why: '一份均衡的坚果 + 种子 + 少量黑巧。',
        ingredients: [
          '杏仁 2 汤匙',
          '南瓜籽 1 汤匙',
          '蔓越莓干 1 汤匙',
          '黑巧克力碎 1 茶匙（70% 以上）'
        ],
        steps: [
          '混合均匀，分装小瓶。'
        ],
        notes: '分量别大——坚果热量高。一次做一周的。'
      },
      macros: {
        protein: {
          g: 6,
          pct: 12
        },
        fat: {
          g: 14,
          pct: 60
        },
        netCarbs: {
          g: 8,
          pct: 28
        }
      }
    },
    {
      id: 's10',
      type: 'snack',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'high-protein',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'dairy'
      ],
      focus: [
        'High protein',
        'No-cook'
      ],
      img: null,
      emoji: '🍍',
      en: {
        name: 'Cottage Cheese & Pineapple',
        time: '2 min',
        servings: '1',
        why: 'High protein, refreshing — a satisfying sweet-and-savoury snack.',
        ingredients: [
          'Cottage cheese 150g',
          'Pineapple 1/2 cup (fresh or tinned in juice)',
          'Cinnamon, a pinch'
        ],
        steps: [
          'Spoon the cottage cheese into a bowl.',
          'Add pineapple and a dust of cinnamon.'
        ],
        notes: 'Use frozen pineapple chunks — they chill the snack like ice cream.'
      },
      zh: {
        name: '茅屋奶酪配菠萝',
        time: '2 分钟',
        servings: '1 份',
        why: '高蛋白、清爽——甜咸兼具的满足零食。',
        ingredients: [
          '茅屋奶酪 150g',
          '菠萝 1/2 杯（新鲜或果汁浸罐头）',
          '肉桂粉 少许'
        ],
        steps: [
          '茅屋奶酪盛入碗中。',
          '加菠萝，撒肉桂粉。'
        ],
        notes: '用冷冻菠萝丁，吃起来像冰淇淋。'
      },
      macros: {
        protein: {
          g: 14,
          pct: 38
        },
        fat: {
          g: 2,
          pct: 10
        },
        netCarbs: {
          g: 11,
          pct: 52
        }
      }
    },
    {
      id: 's11',
      type: 'snack',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'nuts'
      ],
      focus: [
        'No-cook',
        'Quick & easy'
      ],
      img: null,
      emoji: '🥒',
      en: {
        name: 'Celery & Peanut Butter',
        time: '2 min',
        servings: '1',
        why: 'A classic low-carb snack — fibre from celery, healthy fat from peanut butter.',
        ingredients: [
          'Celery 2 stalks',
          'Unsweetened peanut butter 2 tbsp'
        ],
        steps: [
          'Cut the celery into sticks; spread with peanut butter.'
        ],
        notes: 'Use sunflower seed butter for nut-free; almond butter also works.'
      },
      zh: {
        name: '芹菜配花生酱',
        time: '2 分钟',
        servings: '1 份',
        why: '经典低碳零食，芹菜纤维 + 花生酱好脂肪。',
        ingredients: [
          '芹菜 2 根',
          '无糖花生酱 2 汤匙'
        ],
        steps: [
          '芹菜切条，抹花生酱即可。'
        ],
        notes: '无坚果者用葵花籽酱；杏仁酱也行。'
      },
      macros: {
        protein: {
          g: 4,
          pct: 12
        },
        fat: {
          g: 8,
          pct: 55
        },
        netCarbs: {
          g: 5,
          pct: 33
        }
      }
    },
    {
      id: 's12',
      type: 'snack',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'high-protein',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'egg'
      ],
      focus: [
        'High protein',
        'No-cook'
      ],
      img: null,
      emoji: '🥑',
      en: {
        name: 'Hard-Boiled Egg & Avocado',
        time: '5 min',
        servings: '1',
        why: 'A protein-and-fat snack that holds you over until the next meal.',
        ingredients: [
          'Hard-boiled egg 1',
          'Avocado 1/4 (sliced)',
          'Sea salt, black pepper, paprika'
        ],
        steps: [
          'Slice the egg; fan with avocado slices.',
          'Season with salt, pepper and paprika.'
        ],
        notes: 'Boil eggs in batches — they keep 7 days in the fridge.'
      },
      zh: {
        name: '水煮蛋配牛油果',
        time: '5 分钟',
        servings: '1 份',
        why: '蛋白 + 好脂肪零食，撑到下一顿。',
        ingredients: [
          '水煮蛋 1 个',
          '牛油果 1/4 个（切片）',
          '海盐、黑胡椒、红椒粉 适量'
        ],
        steps: [
          '鸡蛋切片，与牛油果片摆盘。',
          '撒盐、胡椒与红椒粉。'
        ],
        notes: '鸡蛋一次煮一批——冷藏可存 7 天。'
      },
      macros: {
        protein: {
          g: 14,
          pct: 38
        },
        fat: {
          g: 12,
          pct: 42
        },
        netCarbs: {
          g: 4,
          pct: 20
        }
      }
    },
    {
      id: 's13',
      type: 'snack',
      carb: 'low',
      tags: [
        'no-cook',
        'quick-easy',
        'vegan',
        'vegetarian',
        'gluten-free'
      ],
      contains: [
        'nuts'
      ],
      focus: [
        'No-cook',
        'Quick & easy'
      ],
      img: null,
      emoji: '🍫',
      en: {
        name: 'Dark Chocolate & Almonds',
        time: '1 min',
        servings: '1',
        why: 'Antioxidant-rich dark chocolate plus protein-rich almonds — a small, satisfying treat.',
        ingredients: [
          'Dark chocolate 1 square (70%+)',
          'Almonds 10'
        ],
        steps: [
          'Eat together slowly.'
        ],
        notes: 'Choose 70%+ dark chocolate for the lowest sugar.'
      },
      zh: {
        name: '黑巧配杏仁',
        time: '1 分钟',
        servings: '1 份',
        why: '抗氧化黑巧 + 高蛋白杏仁，一份满足的小零食。',
        ingredients: [
          '黑巧克力 1 块（70% 以上）',
          '杏仁 10 颗'
        ],
        steps: [
          '慢慢一起吃。'
        ],
        notes: '选 70% 以上黑巧糖最低。'
      },
      macros: {
        protein: {
          g: 3,
          pct: 10
        },
        fat: {
          g: 12,
          pct: 55
        },
        netCarbs: {
          g: 7,
          pct: 35
        }
      }
    }
  ]

/* Expose to browser */
if (typeof window !== 'undefined') window.MEALS = MEALS;
